"""
Robust diagnostics for fixed-anchor deep/slack SR tests.

Run after:
    %run -i deu_sr_fixed_anchor_twin_patch.py
    %run -i deu_sr_fixed_anchor_slack_scale_patch.py   # optional, but useful

This patch does not change geometry. It adds safe wrappers that:
  * diagnose available rest heights before filtering;
  * avoid hard failures when no diamonds satisfy min_T_rest_edges;
  * optionally run the slack audit on all sampled gap bins rather than only the selected SR window;
  * sweep thresholds so we can tell whether the obstruction is code or a real height ceiling.
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, Optional, Sequence, Tuple, List
import numpy as np
import pandas as pd


def _deepdiag_req(name: str):
    if name not in globals():
        raise RuntimeError(f"Missing {name!r}; run the fixed-anchor/slack patches first.")


def _deepdiag_interval_height_df(foam_result: Dict, max_scan: int = 8000) -> pd.DataFrame:
    """Return sampled foam diamonds with exact A->B rest height T_rest_edges_exact."""
    _deepdiag_req("_fa_interval_height_edges")
    rg2 = foam_result["rg2"]
    if "diamonds" not in foam_result:
        raise ValueError("foam_result must contain a 'diamonds' DataFrame")
    df = foam_result["diamonds"].copy().reset_index(drop=True)
    if len(df) == 0:
        return df
    if "V" not in df.columns:
        if "V_strict_prescan" in df.columns:
            df["V"] = df["V_strict_prescan"]
        elif "interval_bits" in df.columns:
            df["V"] = df["interval_bits"].map(lambda x: int(x).bit_count())
        else:
            df["V"] = np.nan
    # Prefer scanning large-volume candidates because they are more likely to be tall.
    if len(df) > int(max_scan):
        df = df.sort_values("V", ascending=False).head(int(max_scan)).reset_index(drop=True)
    h_inc, h_edges, vols = [], [], []
    for row in df.itertuples(index=False):
        try:
            a = int(getattr(row, "a_index"))
            b = int(getattr(row, "b_index"))
            h, e, v = _fa_interval_height_edges(rg2, a, b)
        except Exception:
            h, e, v = np.nan, np.nan, np.nan
        h_inc.append(h); h_edges.append(e); vols.append(v)
    df["h_rest_inclusive_exact"] = h_inc
    df["T_rest_edges_exact"] = h_edges
    df["V_exact"] = vols
    return df


def diagnose_fixed_anchor_height_availability(
    foam_result: Dict,
    selected_gap_bins: Optional[Sequence[int]] = None,
    prefer_sr_window: bool = True,
    thresholds: Sequence[int] = (20, 23, 24, 25, 30, 35, 40, 50, 60),
    max_scan: int = 8000,
) -> Dict:
    """Summarize exact rest-height availability in selected and all sampled diamonds."""
    df = _deepdiag_interval_height_df(foam_result, max_scan=max_scan)
    if selected_gap_bins is None and prefer_sr_window:
        selected_gap_bins = foam_result.get("selected_gap_bins", None)
    if selected_gap_bins is not None and "gap_bin" in df.columns:
        df_sel = df[df["gap_bin"].isin(list(selected_gap_bins))].copy()
    else:
        df_sel = df.copy()

    def _summarize(sub: pd.DataFrame, label: str) -> Dict:
        T = sub["T_rest_edges_exact"].dropna().astype(float) if "T_rest_edges_exact" in sub else pd.Series([], dtype=float)
        row = {"scope": label, "n": int(len(T))}
        if len(T):
            row.update({
                "T_min": float(T.min()),
                "T_q25": float(T.quantile(0.25)),
                "T_med": float(T.median()),
                "T_q75": float(T.quantile(0.75)),
                "T_q90": float(T.quantile(0.90)),
                "T_max": float(T.max()),
            })
            for th in thresholds:
                row[f"n_T_ge_{int(th)}"] = int((T >= int(th)).sum())
        else:
            row.update({"T_min": np.nan, "T_q25": np.nan, "T_med": np.nan, "T_q75": np.nan, "T_q90": np.nan, "T_max": np.nan})
            for th in thresholds:
                row[f"n_T_ge_{int(th)}"] = 0
        return row

    scope_summary = pd.DataFrame([
        _summarize(df, "all_sampled_gap_bins"),
        _summarize(df_sel, "selected_sr_gap_bins"),
    ])

    by_gap = pd.DataFrame()
    if "gap_bin" in df.columns:
        rows = []
        for gb, sub in df.groupby("gap_bin"):
            row = _summarize(sub, f"gap_bin_{gb}")
            row["gap_bin"] = gb
            if "gap_lo" in sub.columns: row["gap_lo"] = float(sub["gap_lo"].iloc[0])
            if "gap_hi" in sub.columns: row["gap_hi"] = float(sub["gap_hi"].iloc[0])
            rows.append(row)
        by_gap = pd.DataFrame(rows).sort_values("gap_bin").reset_index(drop=True)

    return {"diamonds_with_heights": df, "selected_with_heights": df_sel, "scope_summary": scope_summary, "by_gap": by_gap}


def run_fixed_anchor_slack_threshold_sweep(
    foam_result: Dict,
    foam_label: str = "foam_cap512_SR_window",
    thresholds: Sequence[int] = (40, 35, 30, 25, 24, 23, 20, 0),
    scopes: Sequence[str] = ("selected", "all"),
    max_intervals: int = 80,
    v_targets: Sequence[float] = (0.0, 0.2, 0.4, 0.6, 0.75),
    v_band: float = 0.10,
    mid_t_band: float = 0.10,
    out_dir: Optional[Path] = None,
    run_label: str = "threshold_sweep",
) -> Dict:
    """Try fixed-anchor slack at several T thresholds without raising on empty thresholds."""
    _deepdiag_req("run_fixed_anchor_slack_scale_from_foam_result")
    diag = diagnose_fixed_anchor_height_availability(foam_result)
    rows = []
    results = {}
    for scope in scopes:
        prefer = (scope == "selected")
        selected_gap_bins = foam_result.get("selected_gap_bins", None) if prefer else None
        for th in thresholds:
            key = f"{scope}_Tge{int(th)}"
            try:
                res = run_fixed_anchor_slack_scale_from_foam_result(
                    foam_result,
                    foam_label=foam_label,
                    selected_gap_bins=selected_gap_bins,
                    prefer_sr_window=prefer,
                    max_intervals=max_intervals,
                    min_T_rest_edges=int(th),
                    v_targets=v_targets,
                    v_band=v_band,
                    mid_t_band=mid_t_band,
                    run_label=f"{run_label}_{key}",
                    out_dir=out_dir,
                )
                byv = res.get("slack_by_velocity", pd.DataFrame())
                high = byv[byv.get("v_target", pd.Series(dtype=float)).astype(float) >= 0.55] if len(byv) else pd.DataFrame()
                selected = res.get("selected_diamonds", pd.DataFrame())
                rows.append({
                    "scope": scope,
                    "threshold": int(th),
                    "status": "ok",
                    "n_selected_diamonds": int(len(selected)),
                    "T_min": float(selected["T_rest_edges_exact"].min()) if len(selected) else np.nan,
                    "T_med": float(selected["T_rest_edges_exact"].median()) if len(selected) else np.nan,
                    "T_max": float(selected["T_rest_edges_exact"].max()) if len(selected) else np.nan,
                    "high_v_deficit_capture_med": float(np.nanmedian(high["deficit_capture_med"])) if len(high) else np.nan,
                    "high_v_slack_frac_med": float(np.nanmedian(high["slack_frac_of_T_med"])) if len(high) else np.nan,
                    "verdict": res.get("verdict", ""),
                })
                results[key] = res
            except Exception as e:
                rows.append({
                    "scope": scope,
                    "threshold": int(th),
                    "status": "empty_or_error",
                    "n_selected_diamonds": 0,
                    "T_min": np.nan,
                    "T_med": np.nan,
                    "T_max": np.nan,
                    "high_v_deficit_capture_med": np.nan,
                    "high_v_slack_frac_med": np.nan,
                    "verdict": str(e),
                })
    sweep = pd.DataFrame(rows)
    if out_dir is not None:
        out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
        diag["scope_summary"].to_csv(out / f"fixed_anchor_height_scope_summary_{run_label}.csv", index=False)
        diag["by_gap"].to_csv(out / f"fixed_anchor_height_by_gap_{run_label}.csv", index=False)
        sweep.to_csv(out / f"fixed_anchor_slack_threshold_sweep_{run_label}.csv", index=False)
    return {"height_diagnostics": diag, "sweep_summary": sweep, "sweep_results": results}


def run_cap512_deep_sr_then_slack_safe(
    target_basin_splits: int = 20000,
    cap: int = 512,
    seed: int = 101,
    ep_lo: Optional[int] = 9,
    ep_hi: Optional[int] = None,
    gap_bins: Sequence[Tuple[int, int]] = ((4, 8), (8, 12), (12, 16), (16, 24), (24, 32), (32, 48), (48, 64)),
    n_endpoint_samples_per_bin: int = 3000,
    keep_top_per_bin: int = 50,
    max_intervals: int = 60,
    thresholds: Sequence[int] = (40, 35, 30, 25, 24, 23, 20, 0),
    run_label: str = "cap512_deep_slack_safe",
    out_dir: Optional[Path] = None,
) -> Dict:
    """Deep helper that always returns diagnostics instead of raising on min_T filters."""
    _deepdiag_req("run_foam_sr_sample")
    foam = run_foam_sr_sample(
        cap=int(cap),
        seed=int(seed),
        target_basin_splits=int(target_basin_splits),
        ep_lo=ep_lo,
        ep_hi=ep_hi,
        gap_bins=gap_bins,
        n_endpoint_samples_per_bin=int(n_endpoint_samples_per_bin),
        keep_top_per_bin=int(keep_top_per_bin),
        n_profile_bins=21,
        choose_window=True,
    )
    sweep = run_fixed_anchor_slack_threshold_sweep(
        foam,
        foam_label=f"foam_cap{cap}_SR_window",
        thresholds=thresholds,
        scopes=("selected", "all"),
        max_intervals=int(max_intervals),
        out_dir=out_dir,
        run_label=run_label,
    )
    return {"foam_result": foam, **sweep}
