"""
Volume-derived Lorentz-factor audit for DEU triangular foam SR window.

Run after the SR fingerprint notebook and the radar patch have been loaded, e.g.

    %run -i src/deu_sr_fingerprint.py
    %run -i deu_sr_lorentz_radar_patch.py
    %run -i deu_sr_volume_gamma_patch.py

Typical cap-512 use:

    vol_gamma_512 = run_volume_gamma_audit_from_foam_result(
        foam_result_512,
        foam_label="foam_cap512_SR_window",
        max_foam_intervals=80,
        control_reps=8,
        n_control_sizes=8,
        seed=51288,
        run_label="cap512",
        out_dir=OUT,
    )
    display(vol_gamma_512["summary"])
    display(vol_gamma_512["gamma_bins"])
    display(vol_gamma_512["gamma_diagnostics"])
    print(vol_gamma_512["verdict"])

Goal:
  Avoid the small-denominator singularity in event-wise gamma=t/tau_chain by
  deriving gamma from Alexandrov interval volumes. In D-dimensional flat
  Lorentzian geometry, V(A,x) = C_D rho tau(A,x)^D. For an observer-chain rest
  endpoint at the same radar time t, V_rest(t) = C_D rho t^D, so

      gamma_vol = (V_rest(t) / V(A,x)) ** (1/D)

  should agree with gamma_SR = 1/sqrt(1-v^2), where v = r/t from graph radar
  coordinates.

Caveats:
  - This is a finite graph-SR consistency test, not a proof of exact Lorentz
    invariance.
  - It relies on the previously established D≈3 flat interval scaling window.
  - It should be interpreted alongside the interval-fingerprint controls.
"""
from __future__ import annotations

import math
from pathlib import Path
from typing import Dict, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


def _linfit(x, y, min_points: int = 5) -> Dict[str, float]:
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    m = np.isfinite(x) & np.isfinite(y)
    x = x[m]
    y = y[m]
    if len(x) < min_points:
        return {"slope": np.nan, "intercept": np.nan, "r2": np.nan, "corr": np.nan, "n_fit": int(len(x))}
    slope, intercept = np.polyfit(x, y, 1)
    pred = intercept + slope * x
    ss_res = float(np.sum((y - pred) ** 2))
    ss_tot = float(np.sum((y - y.mean()) ** 2))
    r2 = np.nan if ss_tot <= 0 else 1.0 - ss_res / ss_tot
    corr = float(np.corrcoef(x, y)[0, 1]) if np.std(x) > 0 and np.std(y) > 0 else np.nan
    return {"slope": float(slope), "intercept": float(intercept), "r2": float(r2), "corr": corr, "n_fit": int(len(x))}


def _safe_ratio(a, b):
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    out = np.full_like(a, np.nan, dtype=float)
    m = np.isfinite(a) & np.isfinite(b) & (b > 0)
    out[m] = a[m] / b[m]
    return out


def _rest_volume_curve(causet, chain: Sequence[int], a_index: int) -> pd.DataFrame:
    """Strict interval volume from bottom a_index to each observer-chain tick."""
    rows = []
    a_index = int(a_index)
    for k, x in enumerate(chain):
        x = int(x)
        if k == 0:
            V = 0
        else:
            V = int((causet.descendant_bits[a_index] & causet.ancestor_bits[x]).bit_count())
        rows.append({"tick": float(k), "observer_index": x, "V_rest_strict": int(V)})
    df = pd.DataFrame(rows)
    if len(df):
        # Strict interval volumes should be nondecreasing along a chain in exact arithmetic,
        # but cummax protects against any pathological/coarse-graining edge case.
        df["V_rest_monotone"] = np.maximum.accumulate(df["V_rest_strict"].astype(float).to_numpy())
    return df


def _interp_rest_volume(rest_curve: pd.DataFrame, t_values, min_rest_V: int = 5):
    """Linear interpolation of the observed rest-volume curve V_rest(t)."""
    t_values = np.asarray(t_values, dtype=float)
    out = np.full_like(t_values, np.nan, dtype=float)
    if rest_curve is None or len(rest_curve) == 0:
        return out
    rc = rest_curve[np.isfinite(rest_curve["tick"]) & np.isfinite(rest_curve["V_rest_monotone"])].copy()
    rc = rc[rc["V_rest_monotone"] >= float(min_rest_V)].copy()
    if len(rc) < 2:
        return out
    ticks = rc["tick"].to_numpy(dtype=float)
    vols = rc["V_rest_monotone"].to_numpy(dtype=float)
    # np.interp extrapolates flat by default; avoid that by masking to in-range values.
    m = (t_values >= ticks.min()) & (t_values <= ticks.max())
    out[m] = np.interp(t_values[m], ticks, vols)
    return out


def volume_gamma_coordinates_for_interval(
    causet,
    strict_bits: int,
    a_index: int,
    b_index: int,
    interval_id: str = "interval",
    model: str = "model",
    spacetime_dim: float = 3.0,
    min_moving_V: int = 5,
    min_rest_V: int = 5,
) -> Tuple[pd.DataFrame, Dict[str, float], pd.DataFrame]:
    """
    Build graph radar coordinates and derive gamma from volume ratios.

    Requires the radar patch functions in scope:
      _extract_longest_chain_from_interval, _precedes_or_equal,
      longest_chain_layers_bits, iter_bits, bit_at
    """
    strict_bits = int(strict_bits)
    a_index = int(a_index)
    b_index = int(b_index)
    D = float(spacetime_dim)
    inclusive_bits = strict_bits | bit_at(a_index) | bit_at(b_index)
    ranks, layers, height = longest_chain_layers_bits(causet, inclusive_bits)
    chain = _extract_longest_chain_from_interval(causet, inclusive_bits, a_index, b_index)
    H = len(chain)
    if H < 4:
        meta = {"interval_id": interval_id, "model": model, "status": "no_observer_chain", "observer_height": H}
        return pd.DataFrame(), meta, pd.DataFrame()

    rest_curve = _rest_volume_curve(causet, chain, a_index)
    rows = []
    event_bits = strict_bits | bit_at(b_index)
    for x in iter_bits(event_bits):
        x = int(x)
        p = None
        q = None
        for k, oi in enumerate(chain):
            if _precedes_or_equal(causet, oi, x):
                p = k
            if q is None and _precedes_or_equal(causet, x, oi):
                q = k
        if p is None or q is None or q < p:
            continue
        t = 0.5 * (p + q)
        r = 0.5 * (q - p)
        if t <= 0:
            continue
        v = r / t
        if not np.isfinite(v) or v < 0 or v >= 1:
            continue
        V_move = int((causet.descendant_bits[a_index] & causet.ancestor_bits[x]).bit_count()) if x != a_index else 0
        if V_move < int(min_moving_V):
            continue
        V_rest = float(_interp_rest_volume(rest_curve, np.array([t], dtype=float), min_rest_V=min_rest_V)[0])
        if not np.isfinite(V_rest) or V_rest <= 0:
            continue
        gamma_vol = (V_rest / float(V_move)) ** (1.0 / D)
        gamma_pred = 1.0 / math.sqrt(max(1e-12, 1.0 - v * v))
        vol_ratio = float(V_move) / float(V_rest)
        one_minus_v2 = max(1e-12, 1.0 - v * v)
        rows.append({
            "model": model,
            "interval_id": interval_id,
            "event_index": x,
            "is_top": bool(x == b_index),
            "on_observer": bool(p == q),
            "observer_height": int(H),
            "interval_height": int(height),
            "p_tick": int(p),
            "q_tick": int(q),
            "t_radar": float(t),
            "r_radar": float(r),
            "v_radar": float(v),
            "V_move": int(V_move),
            "V_rest_interp": float(V_rest),
            "volume_ratio_move_over_rest": float(vol_ratio),
            "one_minus_v2": float(one_minus_v2),
            "gamma_volume_D3": float(gamma_vol),
            "gamma_pred": float(gamma_pred),
            "gamma_volume_rel_err": float(abs(gamma_vol - gamma_pred) / max(1e-12, gamma_pred)),
            "D_used": float(D),
        })
    df = pd.DataFrame(rows)
    meta = {
        "interval_id": interval_id,
        "model": model,
        "status": "ok" if len(df) else "no_valid_volume_gamma_events",
        "observer_height": int(H),
        "interval_height": int(height),
        "V_strict": int(strict_bits.bit_count()),
        "n_volume_gamma_events": int(len(df)),
        "rest_curve_valid_ticks": int((rest_curve.get("V_rest_monotone", pd.Series(dtype=float)) >= min_rest_V).sum()) if len(rest_curve) else 0,
    }
    return df, meta, rest_curve


def _audit_many_volume_gamma(causet, diamond_rows: pd.DataFrame, model: str, max_intervals: int = 80, spacetime_dim: float = 3.0) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    rows = []
    metas = []
    curves = []
    if diamond_rows is None or len(diamond_rows) == 0:
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()
    df = diamond_rows.copy()
    if "V" not in df.columns:
        if "V_strict_prescan" in df.columns:
            df["V"] = df["V_strict_prescan"]
        else:
            df["V"] = df["interval_bits"].map(lambda x: int(x).bit_count())
    df = df.sort_values("V", ascending=False).head(int(max_intervals)).copy()
    for k, row in enumerate(df.itertuples(index=False)):
        strict_bits = int(getattr(row, "interval_bits"))
        a = int(getattr(row, "a_index"))
        b = int(getattr(row, "b_index"))
        rid = f"{model}_d{k}"
        ev, meta, rc = volume_gamma_coordinates_for_interval(causet, strict_bits, a, b, interval_id=rid, model=model, spacetime_dim=spacetime_dim)
        for col in ["gap_bin", "gap_lo", "gap_hi", "epoch_gap", "ep_a", "ep_b"]:
            if hasattr(row, col):
                if len(ev):
                    ev[col] = getattr(row, col)
                meta[col] = getattr(row, col)
        if len(ev):
            rows.append(ev)
        if len(rc):
            rc = rc.copy(); rc["interval_id"] = rid; rc["model"] = model
            curves.append(rc)
        metas.append(meta)
    return (
        pd.concat(rows, ignore_index=True) if rows else pd.DataFrame(),
        pd.DataFrame(metas),
        pd.concat(curves, ignore_index=True) if curves else pd.DataFrame(),
    )


def build_control_volume_gamma_samples(
    sizes: Sequence[int],
    reps_per_size: int = 4,
    seed: int = 12345,
    spacetime_dim: float = 3.0,
    models: Sequence[str] = ("minkowski_2p1D", "minkowski_3p1D", "random_DAG", "chain_1D"),
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    all_events = []
    all_meta = []
    all_curves = []
    for n in sizes:
        n = int(max(8, n))
        if "chain_1D" in models:
            c, a, b = make_chain_interval_causet(n)
            ev, meta, rc = volume_gamma_coordinates_for_interval(c, c.descendant_bits[a] & c.ancestor_bits[b], a, b, interval_id=f"chain_n{n}", model="chain_1D", spacetime_dim=spacetime_dim)
            if len(ev): all_events.append(ev)
            if len(rc): all_curves.append(rc.assign(interval_id=f"chain_n{n}", model="chain_1D"))
            all_meta.append(meta)
        for rep in range(int(reps_per_size)):
            base = int(seed + 100000 * rep + 97 * n)
            if "minkowski_2p1D" in models:
                c, a, b = make_minkowski_interval_causet(n, d=3, seed=base + 3)
                iid = f"minkowski_2p1D_n{n}_r{rep}"
                ev, meta, rc = volume_gamma_coordinates_for_interval(c, c.descendant_bits[a] & c.ancestor_bits[b], a, b, interval_id=iid, model="minkowski_2p1D", spacetime_dim=spacetime_dim)
                if len(ev): all_events.append(ev)
                if len(rc): all_curves.append(rc.assign(interval_id=iid, model="minkowski_2p1D"))
                all_meta.append(meta)
            if "minkowski_3p1D" in models:
                c, a, b = make_minkowski_interval_causet(n, d=4, seed=base + 4)
                iid = f"minkowski_3p1D_n{n}_r{rep}"
                # Still use D=3 for gamma_volume_D3 target because we are testing the 2+1D formula;
                # this should make 3+1D a discriminating control.
                ev, meta, rc = volume_gamma_coordinates_for_interval(c, c.descendant_bits[a] & c.ancestor_bits[b], a, b, interval_id=iid, model="minkowski_3p1D", spacetime_dim=spacetime_dim)
                if len(ev): all_events.append(ev)
                if len(rc): all_curves.append(rc.assign(interval_id=iid, model="minkowski_3p1D"))
                all_meta.append(meta)
            if "random_DAG" in models:
                c, a, b = make_random_dag_interval_causet(n, p=0.025, seed=base + 999)
                iid = f"random_DAG_n{n}_r{rep}"
                ev, meta, rc = volume_gamma_coordinates_for_interval(c, c.descendant_bits[a] & c.ancestor_bits[b], a, b, interval_id=iid, model="random_DAG", spacetime_dim=spacetime_dim)
                if len(ev): all_events.append(ev)
                if len(rc): all_curves.append(rc.assign(interval_id=iid, model="random_DAG"))
                all_meta.append(meta)
    return (
        pd.concat(all_events, ignore_index=True) if all_events else pd.DataFrame(),
        pd.DataFrame(all_meta),
        pd.concat(all_curves, ignore_index=True) if all_curves else pd.DataFrame(),
    )


def volume_gamma_fit_filter(events: pd.DataFrame, min_V: int = 10, v_min: float = 0.05, v_max: float = 0.92) -> pd.DataFrame:
    df = events.copy()
    need = ["is_top", "on_observer", "v_radar", "V_move", "V_rest_interp", "gamma_volume_D3", "gamma_pred", "volume_ratio_move_over_rest", "one_minus_v2"]
    for c in need:
        if c not in df.columns:
            raise ValueError(f"events missing required column: {c}")
    return df[
        (~df["is_top"].astype(bool))
        & (~df["on_observer"].astype(bool))
        & np.isfinite(df["v_radar"])
        & (df["v_radar"] >= float(v_min))
        & (df["v_radar"] <= float(v_max))
        & (df["V_move"] >= int(min_V))
        & (df["V_rest_interp"] >= int(min_V))
        & np.isfinite(df["gamma_volume_D3"])
        & np.isfinite(df["gamma_pred"])
        & (df["gamma_pred"] > 0)
        & (df["volume_ratio_move_over_rest"] > 0)
        & (df["one_minus_v2"] > 0)
    ].copy()


def summarize_volume_gamma_events(events: pd.DataFrame, model: str) -> Dict[str, float]:
    if events is None or len(events) == 0:
        return {"model": model, "status": "empty"}
    fit = volume_gamma_fit_filter(events)
    if len(fit) == 0:
        return {"model": model, "status": "no_fit_events", "n_events_total": int(len(events)), "n_events_fit": 0}
    gamma_fit = _linfit(fit["gamma_pred"], fit["gamma_volume_D3"], min_points=20)
    rel = np.abs(fit["gamma_volume_D3"] - fit["gamma_pred"]) / np.maximum(1e-12, fit["gamma_pred"])
    # Volume invariant: V_move/V_rest = (1-v^2)^(D/2), D=3.
    x = np.log(np.asarray(fit["one_minus_v2"], dtype=float))
    y = np.log(np.asarray(fit["volume_ratio_move_over_rest"], dtype=float))
    vol_inv_fit = _linfit(x, y, min_points=20)
    return {
        "model": model,
        "status": "ok",
        "n_intervals": int(fit["interval_id"].nunique()),
        "n_events_total": int(len(events)),
        "n_events_fit": int(len(fit)),
        "observer_height_med": float(events.groupby("interval_id")["observer_height"].first().median()),
        "v_median": float(np.nanmedian(fit["v_radar"])),
        "v_q90": float(np.nanquantile(fit["v_radar"], 0.90)),
        "gamma_pred_med": float(np.nanmedian(fit["gamma_pred"])),
        "gamma_volume_med": float(np.nanmedian(fit["gamma_volume_D3"])),
        "gamma_volume_rel_err_median": float(np.nanmedian(rel)),
        "gamma_volume_rel_err_q80": float(np.nanquantile(rel, 0.80)),
        "gamma_volume_slope_vs_pred": gamma_fit["slope"],
        "gamma_volume_intercept": gamma_fit["intercept"],
        "gamma_volume_r2": gamma_fit["r2"],
        "gamma_volume_corr": gamma_fit["corr"],
        "gamma_volume_n_fit": gamma_fit["n_fit"],
        "vol_ratio_log_slope_vs_log_1minusv2": vol_inv_fit["slope"],
        "vol_ratio_log_intercept": vol_inv_fit["intercept"],
        "vol_ratio_log_r2": vol_inv_fit["r2"],
        "vol_ratio_log_corr": vol_inv_fit["corr"],
        "vol_ratio_expected_slope_Dover2": 1.5,
    }


def binned_volume_gamma_diagnostics(
    events: pd.DataFrame,
    v_bins: Sequence[float] = (0.05, 0.15, 0.25, 0.35, 0.45, 0.55, 0.65, 0.75, 0.85, 0.93),
    min_events_per_model_bin: int = 80,
    min_interval_bins: int = 3,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    fit = volume_gamma_fit_filter(events)
    if len(fit) == 0:
        return pd.DataFrame(), pd.DataFrame()
    fit["v_bin"] = pd.cut(fit["v_radar"], bins=list(v_bins), include_lowest=True, right=False)
    fit = fit.dropna(subset=["v_bin"]).copy()
    interval_bin = (
        fit.groupby(["model", "interval_id", "v_bin"], observed=True)
        .agg(
            n_events=("v_radar", "size"),
            v_med=("v_radar", "median"),
            gamma_pred_med=("gamma_pred", "median"),
            gamma_volume_med=("gamma_volume_D3", "median"),
            gamma_volume_rel_err_med=("gamma_volume_rel_err", "median") if "gamma_volume_rel_err" in fit.columns else ("gamma_pred", "size"),
            volume_ratio_med=("volume_ratio_move_over_rest", "median"),
            one_minus_v2_med=("one_minus_v2", "median"),
        )
        .reset_index()
    )
    if "gamma_volume_rel_err_med" not in interval_bin.columns or interval_bin["gamma_volume_rel_err_med"].isna().all():
        interval_bin["gamma_volume_rel_err_med"] = np.abs(interval_bin["gamma_volume_med"] - interval_bin["gamma_pred_med"]) / np.maximum(1e-12, interval_bin["gamma_pred_med"])

    bin_summary = (
        interval_bin.groupby(["model", "v_bin"], observed=True)
        .agg(
            n_interval_bins=("interval_id", "nunique"),
            n_events=("n_events", "sum"),
            v_med=("v_med", "median"),
            gamma_pred_med=("gamma_pred_med", "median"),
            gamma_volume_med=("gamma_volume_med", "median"),
            gamma_volume_rel_err_med=("gamma_volume_rel_err_med", "median"),
            volume_ratio_med=("volume_ratio_med", "median"),
            one_minus_v2_med=("one_minus_v2_med", "median"),
        )
        .reset_index()
    )
    bin_summary = bin_summary[
        (bin_summary["n_events"] >= int(min_events_per_model_bin))
        & (bin_summary["n_interval_bins"] >= int(min_interval_bins))
    ].copy()

    rows = []
    for model, sub in bin_summary.groupby("model", observed=True):
        sub = sub.sort_values("v_med").copy()
        gamma_fit = _linfit(sub["gamma_pred_med"], sub["gamma_volume_med"], min_points=4)
        # log-volume relation in bins.
        x = np.log(np.asarray(sub["one_minus_v2_med"], dtype=float))
        y = np.log(np.asarray(sub["volume_ratio_med"], dtype=float))
        vol_fit = _linfit(x, y, min_points=4)
        diffs = np.diff(sub["gamma_volume_med"].to_numpy(dtype=float)) if len(sub) >= 2 else np.array([])
        rows.append({
            "model": model,
            "n_volume_gamma_bins": int(len(sub)),
            "gamma_pred_min": float(sub["gamma_pred_med"].min()) if len(sub) else np.nan,
            "gamma_pred_max": float(sub["gamma_pred_med"].max()) if len(sub) else np.nan,
            "gamma_volume_min": float(sub["gamma_volume_med"].min()) if len(sub) else np.nan,
            "gamma_volume_max": float(sub["gamma_volume_med"].max()) if len(sub) else np.nan,
            "binned_gamma_volume_slope": gamma_fit["slope"],
            "binned_gamma_volume_intercept": gamma_fit["intercept"],
            "binned_gamma_volume_r2": gamma_fit["r2"],
            "binned_gamma_volume_corr": gamma_fit["corr"],
            "binned_gamma_volume_n_fit": gamma_fit["n_fit"],
            "binned_gamma_volume_monotone_fraction": float(np.mean(diffs >= -1e-9)) if len(diffs) else np.nan,
            "binned_gamma_volume_rel_err_median": float(sub["gamma_volume_rel_err_med"].median()) if len(sub) else np.nan,
            "binned_vol_ratio_log_slope_vs_log_1minusv2": vol_fit["slope"],
            "binned_vol_ratio_log_r2": vol_fit["r2"],
            "binned_vol_ratio_expected_slope_Dover2": 1.5,
        })
    return bin_summary, pd.DataFrame(rows)


def interpret_volume_gamma_summary(summary: pd.DataFrame, diag: pd.DataFrame, foam_label: str) -> str:
    if summary is None or len(summary) == 0 or foam_label not in set(summary["model"]):
        return "UNDETERMINED: no foam volume-gamma summary found."
    row = summary[summary["model"] == foam_label].iloc[0]
    drow = diag[diag["model"] == foam_label].iloc[0] if diag is not None and len(diag) and foam_label in set(diag["model"]) else None
    event_ok = (
        float(row.get("gamma_volume_corr", np.nan)) >= 0.35
        and float(row.get("gamma_volume_r2", np.nan)) >= 0.10
        and 0.35 <= float(row.get("gamma_volume_slope_vs_pred", np.nan)) <= 1.75
        and float(row.get("gamma_volume_rel_err_median", np.inf)) <= 0.35
    )
    vol_law_ok = (
        0.65 <= float(row.get("vol_ratio_log_slope_vs_log_1minusv2", np.nan)) <= 2.35
        and float(row.get("vol_ratio_log_r2", np.nan)) >= 0.15
    )
    binned_ok = False
    if drow is not None:
        binned_ok = (
            float(drow.get("binned_gamma_volume_n_fit", 0)) >= 4
            and float(drow.get("binned_gamma_volume_corr", np.nan)) >= 0.45
            and float(drow.get("binned_gamma_volume_r2", np.nan)) >= 0.20
            and 0.35 <= float(drow.get("binned_gamma_volume_slope", np.nan)) <= 1.75
            and float(drow.get("binned_gamma_volume_monotone_fraction", np.nan)) >= 0.60
            and float(drow.get("binned_gamma_volume_rel_err_median", np.inf)) <= 0.35
        )
    n_ok = float(row.get("n_events_fit", 0)) >= 500
    if event_ok and binned_ok and vol_law_ok and n_ok:
        return "PASS / PROMISING: volume-derived gamma avoids the small-tau singularity and shows a coherent SR-like relation to radar velocity over the selected foam window."
    if (event_ok or binned_ok) and n_ok:
        return "PARTIAL PASS: volume-derived gamma has a detectable SR-like signal, but one or more finite-volume consistency checks are weak. Treat as supporting evidence, not a derivation."
    return "NOT YET PASSING: volume-derived gamma does not yet show a reliable SR-like relation. Keep the SR claim at interval-fingerprint level."


def run_volume_gamma_audit_from_foam_result(
    foam_result: Dict,
    foam_label: str = "foam_SR_window",
    selected_gap_bins: Optional[Sequence[int]] = None,
    max_foam_intervals: int = 80,
    control_reps: int = 8,
    n_control_sizes: int = 8,
    seed: int = 888,
    run_label: str = "volume_gamma",
    out_dir: Optional[Path | str] = None,
    spacetime_dim: float = 3.0,
) -> Dict[str, object]:
    rg2 = foam_result["rg2"]
    diamonds = foam_result["diamonds"].copy()
    if selected_gap_bins is None:
        selected_gap_bins = foam_result.get("selected_gap_bins", None)
    if selected_gap_bins is not None and "gap_bin" in diamonds.columns:
        diamonds = diamonds[diamonds["gap_bin"].isin(list(selected_gap_bins))].copy()
    if len(diamonds) == 0:
        raise ValueError("No diamonds after selected_gap_bins filter.")
    if "V" not in diamonds.columns:
        if "V_strict_prescan" in diamonds.columns:
            diamonds["V"] = diamonds["V_strict_prescan"]
        else:
            diamonds["V"] = diamonds["interval_bits"].map(lambda x: int(x).bit_count())

    foam_events, foam_meta, foam_rest_curves = _audit_many_volume_gamma(rg2, diamonds, model=foam_label, max_intervals=max_foam_intervals, spacetime_dim=spacetime_dim)

    Vvals = diamonds["V"].astype(float).to_numpy()
    qs = np.linspace(0.10, 0.90, int(n_control_sizes))
    sizes = sorted(set(int(max(20, round(np.nanquantile(Vvals, q)))) for q in qs))
    control_events, control_meta, control_rest_curves = build_control_volume_gamma_samples(sizes=sizes, reps_per_size=control_reps, seed=seed, spacetime_dim=spacetime_dim)

    combined_events = pd.concat([foam_events, control_events], ignore_index=True) if len(control_events) else foam_events.copy()
    combined_curves = pd.concat([foam_rest_curves, control_rest_curves], ignore_index=True) if len(control_rest_curves) else foam_rest_curves.copy()

    summaries = []
    for model, sub in combined_events.groupby("model", dropna=False):
        summaries.append(summarize_volume_gamma_events(sub, str(model)))
    summary = pd.DataFrame(summaries)
    order = {foam_label: 0, "minkowski_2p1D": 1, "minkowski_3p1D": 2, "random_DAG": 3, "chain_1D": 4}
    if len(summary):
        summary["_ord"] = summary["model"].map(order).fillna(99)
        summary = summary.sort_values(["_ord", "model"]).drop(columns=["_ord"]).reset_index(drop=True)

    gamma_bins, gamma_diag = binned_volume_gamma_diagnostics(combined_events)
    verdict = interpret_volume_gamma_summary(summary, gamma_diag, foam_label=foam_label)
    result = {
        "summary": summary,
        "events": combined_events,
        "foam_events": foam_events,
        "control_events": control_events,
        "foam_meta": foam_meta,
        "control_meta": control_meta,
        "rest_curves": combined_curves,
        "gamma_bins": gamma_bins,
        "gamma_diagnostics": gamma_diag,
        "control_sizes": sizes,
        "selected_gap_bins": tuple(selected_gap_bins) if selected_gap_bins is not None else None,
        "verdict": verdict,
    }
    if out_dir is not None:
        out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
        summary.to_csv(out / f"volume_gamma_summary_{run_label}.csv", index=False)
        combined_events.to_csv(out / f"volume_gamma_events_{run_label}.csv", index=False)
        gamma_bins.to_csv(out / f"volume_gamma_bins_{run_label}.csv", index=False)
        gamma_diag.to_csv(out / f"volume_gamma_diagnostics_{run_label}.csv", index=False)
        foam_meta.to_csv(out / f"volume_gamma_foam_meta_{run_label}.csv", index=False)
        control_meta.to_csv(out / f"volume_gamma_control_meta_{run_label}.csv", index=False)
        (out / f"volume_gamma_verdict_{run_label}.txt").write_text(verdict, encoding="utf-8")
    return result
