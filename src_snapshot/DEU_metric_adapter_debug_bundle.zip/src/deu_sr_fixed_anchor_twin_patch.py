"""
Fixed-anchor twin-paradox / coarse time-dilation audit for the DEU triangular foam.

Run after the SR fingerprint and radar patches, typically:
    %run -i src/deu_exp456_minimal.py
    %run -i src/deu_exp456_overflow_patch.py
    %run -i src/deu_sr_fingerprint.py
    %run -i deu_sr_lorentz_radar_patch.py
    %run -i deu_sr_fixed_anchor_twin_patch.py

Main entry point:
    fixed_anchor_512 = run_fixed_anchor_twin_audit_from_foam_result(foam_result_512, ...)

Purpose
-------
The earlier velocity-tube clock estimator failed because the longest chain inside a
spatial tube can zig-zag and is not forced to behave like an inertial clock.  This
audit uses exact anchors instead:

    A = lower endpoint of a causal diamond
    B = upper endpoint of the same causal diamond
    C = a strict event near radar time T/2 and chosen lateral radar speed

We compare

    tau_rest   = longest-chain edges A -> B
    tau_moving = longest-chain edges A -> C + C -> B

against the flat-SR broken-worldline prediction using radar coordinates from one
A->B observer chain:

    tau_pred = sqrt(t^2-r^2) + sqrt((T-t)^2-r^2),

where T=tau_rest in graph ticks and (t,r) are radar coordinates of C.

This is still a finite-causet diagnostic, not a proof of Lorentz invariance.  It
must calibrate on finite 2+1D Minkowski controls before foam conclusions are meaningful.
"""

from __future__ import annotations

import math
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


def _fa_require(name: str):
    if name not in globals():
        raise RuntimeError(
            f"Required function/global {name!r} is missing. Run the SR fingerprint "
            "source and deu_sr_lorentz_radar_patch.py first."
        )


def _fa_bitset(indices: Iterable[int]) -> int:
    bits = 0
    for i in indices:
        bits |= bit_at(int(i))
    return int(bits)


def _fa_interval_height_edges(causet, a: int, b: int) -> Tuple[int, int, int]:
    """Return (inclusive_height, edge_height, strict_volume) for interval A->B."""
    a = int(a); b = int(b)
    strict = int(causet.descendant_bits[a] & causet.ancestor_bits[b])
    incl = strict | bit_at(a) | bit_at(b)
    try:
        _, _, h = longest_chain_layers_bits(causet, incl)
    except Exception:
        h = 0
    h = int(h)
    return h, max(0, h - 1), int(strict.bit_count())


def _fa_linear_fit(x, y, min_points: int = 3) -> Dict[str, float]:
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    m = np.isfinite(x) & np.isfinite(y)
    x = x[m]; y = y[m]
    if len(x) < int(min_points):
        return {"slope": np.nan, "intercept": np.nan, "r2": np.nan, "corr": np.nan, "n_fit": int(len(x))}
    slope, intercept = np.polyfit(x, y, 1)
    pred = intercept + slope * x
    ss_res = float(np.sum((y - pred) ** 2))
    ss_tot = float(np.sum((y - y.mean()) ** 2))
    r2 = np.nan if ss_tot <= 0 else 1.0 - ss_res / ss_tot
    corr = float(np.corrcoef(x, y)[0, 1]) if len(x) >= 3 and np.std(x) > 0 and np.std(y) > 0 else np.nan
    return {"slope": float(slope), "intercept": float(intercept), "r2": r2, "corr": corr, "n_fit": int(len(x))}


def _fa_selected_diamonds_from_foam_result(
    foam_result: Dict,
    selected_gap_bins: Optional[Sequence[int]] = None,
    max_intervals: int = 80,
    bulk_epoch_margin: Optional[float] = None,
) -> pd.DataFrame:
    """Select large diamonds, optionally restricted away from the final epoch frontier."""
    diamonds = foam_result["diamonds"].copy()
    if selected_gap_bins is None:
        selected_gap_bins = foam_result.get("selected_gap_bins", None)
    if selected_gap_bins is not None and "gap_bin" in diamonds.columns:
        diamonds = diamonds[diamonds["gap_bin"].isin(list(selected_gap_bins))].copy()
    if len(diamonds) == 0:
        raise ValueError("No diamonds after selected_gap_bins filter.")
    if "V" not in diamonds.columns:
        if "V_strict_prescan" in diamonds.columns:
            diamonds["V"] = diamonds["V_strict_prescan"]
        else:
            diamonds["V"] = diamonds["interval_bits"].map(lambda x: int(x).bit_count())
    # Optional shared-past/frozen-bulk filter: keep top endpoints away from final known epoch.
    if bulk_epoch_margin is not None and "ep_b" in diamonds.columns:
        max_ep = float(np.nanmax(list(foam_result["rg2"].event_epoch.values()))) if hasattr(foam_result.get("rg2"), "event_epoch") else float(np.nanmax(diamonds["ep_b"]))
        diamonds = diamonds[diamonds["ep_b"].astype(float) <= max_ep - float(bulk_epoch_margin)].copy()
        if len(diamonds) == 0:
            raise ValueError("bulk_epoch_margin filter removed all diamonds; reduce the margin.")
    diamonds = diamonds.sort_values("V", ascending=False).head(int(max_intervals)).reset_index(drop=True)
    return diamonds


def fixed_anchor_twin_rows_for_diamonds(
    causet,
    diamond_rows: pd.DataFrame,
    model: str,
    v_targets: Sequence[float] = (0.0, 0.2, 0.4, 0.6, 0.75),
    v_band: float = 0.08,
    mid_t_frac: float = 0.50,
    mid_t_band: float = 0.08,
    min_rest_edges: int = 8,
    min_segment_edges: int = 1,
    max_candidates_per_target: int = 1,
) -> pd.DataFrame:
    """
    Build fixed-anchor A-C-B twin rows for each diamond and target velocity.

    C candidates are strict interval events near radar time mid_t_frac*T.  For each
    target v, choose the event(s) whose actual radar v is closest to target within
    v_band.  Moving proper time is h(A,C)+h(C,B), using exact anchors.
    """
    _fa_require("radar_coordinates_for_interval")
    _fa_require("longest_chain_layers_bits")
    _fa_require("bit_at")

    rows = []
    if diamond_rows is None or len(diamond_rows) == 0:
        return pd.DataFrame()

    for k, row in enumerate(diamond_rows.itertuples(index=False)):
        try:
            strict_bits = int(getattr(row, "interval_bits"))
            a = int(getattr(row, "a_index"))
            b = int(getattr(row, "b_index"))
        except Exception:
            continue
        interval_id = f"{model}_d{k}"
        ev, meta = radar_coordinates_for_interval(causet, strict_bits, a, b, interval_id=interval_id, model=model)
        if ev is None or len(ev) == 0:
            continue
        T = float(meta.get("observer_height", 0) - 1)
        if not np.isfinite(T) or T < int(min_rest_edges):
            continue
        base = ev.copy()
        base = base[(~base.get("is_top", False).astype(bool)) & np.isfinite(base["t_radar"]) & np.isfinite(base["r_radar"])].copy()
        base = base[(base["t_radar"] > 0) & (base["t_radar"] < T)].copy()
        if len(base) == 0:
            continue
        base["t_frac"] = base["t_radar"] / T
        base["v_actual"] = base["r_radar"] / base["t_radar"].replace(0, np.nan)
        # Stay away from active-edge/boundary and use near-reunion midpoint anchors.
        base = base[(base["t_frac"] >= mid_t_frac - mid_t_band) & (base["t_frac"] <= mid_t_frac + mid_t_band)].copy()
        base = base[np.isfinite(base["v_actual"]) & (base["v_actual"] >= 0) & (base["v_actual"] < 0.98)].copy()
        if len(base) == 0:
            continue
        for vt in v_targets:
            vt = float(vt)
            cand = base.copy()
            cand["v_abs_err"] = np.abs(cand["v_actual"] - vt)
            if vt == 0.0:
                # Rest anchor: prefer observer-chain/midline events but still use exact C if available.
                cand2 = cand[cand["r_radar"] <= 0.5].copy()
                if len(cand2):
                    cand = cand2
            else:
                cand = cand[cand["v_abs_err"] <= float(v_band)].copy()
            if len(cand) == 0:
                rows.append({
                    "model": model, "interval_id": interval_id, "diamond_local_id": int(k),
                    "v_target": vt, "status": "no_C_candidate", "T_rest_edges": T,
                })
                continue
            cand = cand.sort_values(["v_abs_err", "subV_from_bottom"], ascending=[True, False]).head(int(max_candidates_per_target))
            for _, c_row in cand.iterrows():
                c = int(c_row["event_index"])
                h_ac, e_ac, V_ac = _fa_interval_height_edges(causet, a, c)
                h_cb, e_cb, V_cb = _fa_interval_height_edges(causet, c, b)
                if e_ac < int(min_segment_edges) or e_cb < int(min_segment_edges):
                    status = "segment_too_short"
                else:
                    status = "ok"
                tau_move = float(e_ac + e_cb)
                t = float(c_row["t_radar"]); r = float(c_row["r_radar"])
                # General broken-path prediction, not assuming exact midpoint.
                seg1 = max(0.0, t * t - r * r)
                seg2 = max(0.0, (T - t) * (T - t) - r * r)
                tau_pred = math.sqrt(seg1) + math.sqrt(seg2)
                gamma_pred = T / tau_pred if tau_pred > 0 else np.nan
                gamma_meas = T / tau_move if tau_move > 0 else np.nan
                tau_ratio = tau_move / T if T > 0 else np.nan
                tau_ratio_pred = tau_pred / T if T > 0 else np.nan
                rel_err_tau = abs(tau_ratio - tau_ratio_pred) / max(1e-9, abs(tau_ratio_pred)) if np.isfinite(tau_ratio_pred) else np.nan
                rel_err_gamma = abs(gamma_meas - gamma_pred) / max(1e-9, abs(gamma_pred)) if np.isfinite(gamma_pred) else np.nan
                rec = {
                    "model": model,
                    "interval_id": interval_id,
                    "diamond_local_id": int(k),
                    "status": status,
                    "v_target": vt,
                    "v_actual": float(c_row["v_actual"]),
                    "v_abs_err": float(abs(c_row["v_actual"] - vt)),
                    "C_index": c,
                    "T_rest_edges": T,
                    "t_radar_C": t,
                    "r_radar_C": r,
                    "t_frac_C": float(c_row["t_frac"]),
                    "tau_AC_edges": float(e_ac),
                    "tau_CB_edges": float(e_cb),
                    "tau_moving_edges": tau_move,
                    "tau_pred_cont": float(tau_pred),
                    "tau_ratio_measured": float(tau_ratio) if np.isfinite(tau_ratio) else np.nan,
                    "tau_ratio_pred": float(tau_ratio_pred) if np.isfinite(tau_ratio_pred) else np.nan,
                    "gamma_measured": float(gamma_meas) if np.isfinite(gamma_meas) else np.nan,
                    "gamma_pred": float(gamma_pred) if np.isfinite(gamma_pred) else np.nan,
                    "tau_rel_err": float(rel_err_tau) if np.isfinite(rel_err_tau) else np.nan,
                    "gamma_rel_err": float(rel_err_gamma) if np.isfinite(rel_err_gamma) else np.nan,
                    "V_AC": int(V_ac),
                    "V_CB": int(V_cb),
                    "subV_from_bottom_C": int(c_row.get("subV_from_bottom", np.nan)) if np.isfinite(c_row.get("subV_from_bottom", np.nan)) else np.nan,
                }
                for col in ["gap_bin", "gap_lo", "gap_hi", "ep_a", "ep_b", "epoch_gap", "V"]:
                    if hasattr(row, col):
                        rec[col] = getattr(row, col)
                rows.append(rec)
    return pd.DataFrame(rows)


def summarize_fixed_anchor_twins(twin_df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Return per-model summary and per-model/per-velocity bin table."""
    if twin_df is None or len(twin_df) == 0:
        return pd.DataFrame(), pd.DataFrame()
    ok = twin_df[twin_df["status"] == "ok"].copy()
    if len(ok) == 0:
        return pd.DataFrame(), pd.DataFrame()
    bin_rows = []
    for (model, vt), sub in ok.groupby(["model", "v_target"], dropna=False):
        bin_rows.append({
            "model": str(model),
            "v_target": float(vt),
            "n_anchors": int(len(sub)),
            "T_rest_edges_med": float(np.nanmedian(sub["T_rest_edges"])),
            "v_actual_med": float(np.nanmedian(sub["v_actual"])),
            "v_abs_err_med": float(np.nanmedian(sub["v_abs_err"])),
            "tau_moving_med": float(np.nanmedian(sub["tau_moving_edges"])),
            "tau_pred_med": float(np.nanmedian(sub["tau_pred_cont"])),
            "tau_ratio_med": float(np.nanmedian(sub["tau_ratio_measured"])),
            "tau_ratio_pred_med": float(np.nanmedian(sub["tau_ratio_pred"])),
            "gamma_med": float(np.nanmedian(sub["gamma_measured"])),
            "gamma_pred_med": float(np.nanmedian(sub["gamma_pred"])),
            "tau_rel_err_med": float(np.nanmedian(sub["tau_rel_err"])),
            "gamma_rel_err_med": float(np.nanmedian(sub["gamma_rel_err"])),
            "segment_min_edges_med": float(np.nanmedian(np.minimum(sub["tau_AC_edges"], sub["tau_CB_edges"]))),
        })
    bins = pd.DataFrame(bin_rows).sort_values(["model", "v_target"]).reset_index(drop=True)

    summary_rows = []
    for model, sub in ok.groupby("model", dropna=False):
        b = bins[bins["model"] == model].sort_values("v_target").copy()
        fit_tau = _fa_linear_fit(sub["tau_ratio_pred"], sub["tau_ratio_measured"], min_points=8)
        fit_gam = _fa_linear_fit(sub["gamma_pred"], sub["gamma_measured"], min_points=8)
        b_fit_tau = _fa_linear_fit(b["tau_ratio_pred_med"], b["tau_ratio_med"], min_points=3)
        b_fit_gam = _fa_linear_fit(b["gamma_pred_med"], b["gamma_med"], min_points=3)
        # Monotone checks over velocity bins: tau should decrease, gamma should increase.
        if len(b) >= 2:
            db = b[b["v_target"] > 0].copy()
            tau_vals = db["tau_ratio_med"].to_numpy(dtype=float)
            gam_vals = db["gamma_med"].to_numpy(dtype=float)
            tau_mono = float(np.mean(np.diff(tau_vals) <= 0)) if len(tau_vals) >= 2 else np.nan
            gam_mono = float(np.mean(np.diff(gam_vals) >= 0)) if len(gam_vals) >= 2 else np.nan
        else:
            tau_mono = gam_mono = np.nan
        summary_rows.append({
            "model": str(model),
            "n_ok_anchors": int(len(sub)),
            "n_intervals": int(sub["interval_id"].nunique()),
            "n_velocity_bins": int(b["v_target"].nunique()) if len(b) else 0,
            "T_rest_edges_med": float(np.nanmedian(sub["T_rest_edges"])),
            "v_actual_med": float(np.nanmedian(sub["v_actual"])),
            "tau_moving_med": float(np.nanmedian(sub["tau_moving_edges"])),
            "tau_ratio_rel_err_med": float(np.nanmedian(sub["tau_rel_err"])),
            "gamma_rel_err_med": float(np.nanmedian(sub["gamma_rel_err"])),
            "tau_fit_slope_event": fit_tau["slope"],
            "tau_fit_r2_event": fit_tau["r2"],
            "tau_fit_corr_event": fit_tau["corr"],
            "gamma_fit_slope_event": fit_gam["slope"],
            "gamma_fit_r2_event": fit_gam["r2"],
            "gamma_fit_corr_event": fit_gam["corr"],
            "tau_fit_slope_binned": b_fit_tau["slope"],
            "tau_fit_r2_binned": b_fit_tau["r2"],
            "tau_fit_corr_binned": b_fit_tau["corr"],
            "gamma_fit_slope_binned": b_fit_gam["slope"],
            "gamma_fit_r2_binned": b_fit_gam["r2"],
            "gamma_fit_corr_binned": b_fit_gam["corr"],
            "tau_monotone_fraction": tau_mono,
            "gamma_monotone_fraction": gam_mono,
            "segment_min_edges_med": float(np.nanmedian(np.minimum(sub["tau_AC_edges"], sub["tau_CB_edges"]))),
        })
    summary = pd.DataFrame(summary_rows).sort_values("model").reset_index(drop=True)
    return summary, bins


def build_fixed_anchor_twin_control_samples(
    sizes: Sequence[int],
    reps_per_size: int = 4,
    seed: int = 123,
    v_targets: Sequence[float] = (0.0, 0.2, 0.4, 0.6, 0.75),
    v_band: float = 0.08,
    mid_t_band: float = 0.08,
) -> pd.DataFrame:
    """Build fixed-anchor twin rows for chain, 2+1D/3+1D Minkowski, and random-DAG controls."""
    rows = []
    for n in sizes:
        # Chain once per size.
        c, a, b = make_chain_interval_causet(int(n))
        strict = int(c.descendant_bits[int(a)] & c.ancestor_bits[int(b)])
        one = pd.DataFrame({
            "interval_bits": pd.Series([strict], dtype=object),
            "a_index": [int(a)],
            "b_index": [int(b)],
            "V": [int(strict.bit_count())],
        })
        r = fixed_anchor_twin_rows_for_diamonds(c, one, "chain_1D", v_targets=v_targets, v_band=v_band, mid_t_band=mid_t_band)
        if len(r): rows.append(r)
        for rep in range(int(reps_per_size)):
            base_seed = int(seed + 100000 * rep + int(n))
            for d, label in [(3, "minkowski_2p1D"), (4, "minkowski_3p1D")]:
                c, a, b = make_minkowski_interval_causet(int(n), d=d, seed=base_seed + 10 * d)
                strict = int(c.descendant_bits[int(a)] & c.ancestor_bits[int(b)])
                one = pd.DataFrame({
                    "interval_bits": pd.Series([strict], dtype=object),
                    "a_index": [int(a)],
                    "b_index": [int(b)],
                    "V": [int(strict.bit_count())],
                })
                r = fixed_anchor_twin_rows_for_diamonds(c, one, label, v_targets=v_targets, v_band=v_band, mid_t_band=mid_t_band)
                if len(r): rows.append(r)
            c, a, b = make_random_dag_interval_causet(int(n), p=0.025, seed=base_seed + 999)
            strict = int(c.descendant_bits[int(a)] & c.ancestor_bits[int(b)])
            one = pd.DataFrame({
                "interval_bits": pd.Series([strict], dtype=object),
                "a_index": [int(a)],
                "b_index": [int(b)],
                "V": [int(strict.bit_count())],
            })
            r = fixed_anchor_twin_rows_for_diamonds(c, one, "random_DAG", v_targets=v_targets, v_band=v_band, mid_t_band=mid_t_band)
            if len(r): rows.append(r)
    return pd.concat(rows, ignore_index=True) if rows else pd.DataFrame()


def _fixed_anchor_verdict(summary: pd.DataFrame, bins: pd.DataFrame, foam_label: str) -> str:
    pieces = []
    if summary is None or len(summary) == 0 or foam_label not in set(summary.get("model", [])):
        return "NOT YET PASSING: no usable fixed-anchor foam result."
    foam = summary[summary["model"] == foam_label].iloc[0]
    if "minkowski_2p1D" not in set(summary["model"]):
        return "INDETERMINATE: no 2+1D Minkowski calibration control."
    m2 = summary[summary["model"] == "minkowski_2p1D"].iloc[0]
    # Control must calibrate before judging foam.
    m2_pass = (
        float(m2.get("n_velocity_bins", 0)) >= 4
        and float(m2.get("tau_fit_corr_binned", np.nan)) > 0.65
        and float(m2.get("gamma_fit_corr_binned", np.nan)) > 0.65
        and float(m2.get("tau_monotone_fraction", np.nan)) >= 0.50
        and float(m2.get("gamma_monotone_fraction", np.nan)) >= 0.50
        and float(m2.get("tau_ratio_rel_err_med", np.nan)) < 0.35
    )
    if m2_pass:
        pieces.append("fixed-anchor estimator calibrates on 2+1D Minkowski controls")
    else:
        pieces.append("fixed-anchor estimator does not calibrate cleanly on 2+1D controls")
    foam_pass = (
        float(foam.get("n_velocity_bins", 0)) >= 4
        and float(foam.get("tau_fit_corr_binned", np.nan)) > 0.50
        and float(foam.get("gamma_fit_corr_binned", np.nan)) > 0.50
        and float(foam.get("tau_monotone_fraction", np.nan)) >= 0.50
        and float(foam.get("gamma_monotone_fraction", np.nan)) >= 0.50
        and float(foam.get("tau_ratio_rel_err_med", np.nan)) < 0.45
    )
    if foam_pass:
        pieces.append("foam fixed-anchor twin ratios show monotone SR-like time-dilation trend")
    else:
        pieces.append("foam fixed-anchor twin ratios do not yet show reliable time dilation")
    if m2_pass and foam_pass:
        return "PASS / PROMISING: fixed-anchor A-C-B twin audit recovers coarse SR-like time dilation. " + "; ".join(pieces)
    if not m2_pass:
        return "PARTIAL/INDETERMINATE: estimator is not reliable enough even on controls. " + "; ".join(pieces)
    return "NOT YET PASSING: controls calibrate, but foam does not pass fixed-anchor time dilation. " + "; ".join(pieces)


def run_fixed_anchor_twin_audit_from_foam_result(
    foam_result: Dict,
    foam_label: str = "foam_cap512_SR_window",
    selected_gap_bins: Optional[Sequence[int]] = None,
    max_foam_intervals: int = 80,
    control_reps: int = 8,
    n_control_sizes: int = 8,
    v_targets: Sequence[float] = (0.0, 0.2, 0.4, 0.6, 0.75),
    v_band: float = 0.08,
    mid_t_band: float = 0.08,
    bulk_epoch_margin: Optional[float] = None,
    seed: int = 12345,
    run_label: str = "fixed_anchor",
    out_dir: Optional[Path] = None,
) -> Dict:
    """End-to-end fixed-anchor twin audit with matched finite controls."""
    required = [
        "make_chain_interval_causet", "make_minkowski_interval_causet", "make_random_dag_interval_causet",
        "radar_coordinates_for_interval", "longest_chain_layers_bits", "bit_at"
    ]
    for name in required:
        _fa_require(name)

    rg2 = foam_result["rg2"]
    diamonds = _fa_selected_diamonds_from_foam_result(
        foam_result,
        selected_gap_bins=selected_gap_bins,
        max_intervals=int(max_foam_intervals),
        bulk_epoch_margin=bulk_epoch_margin,
    )
    foam_rows = fixed_anchor_twin_rows_for_diamonds(
        rg2,
        diamonds,
        foam_label,
        v_targets=v_targets,
        v_band=float(v_band),
        mid_t_band=float(mid_t_band),
    )
    # Match control sizes to selected foam diamond volumes.
    if len(diamonds) and "V" in diamonds:
        Vvals = diamonds["V"].to_numpy(dtype=float)
    else:
        Vvals = np.array([80, 120, 180, 260, 400], dtype=float)
    qs = np.linspace(0.10, 0.90, int(n_control_sizes))
    sizes = sorted(set(int(max(20, round(np.nanquantile(Vvals, q)))) for q in qs))
    control_rows = build_fixed_anchor_twin_control_samples(
        sizes=sizes,
        reps_per_size=int(control_reps),
        seed=int(seed) + 1000,
        v_targets=v_targets,
        v_band=float(v_band),
        mid_t_band=float(mid_t_band),
    )
    all_rows = pd.concat([foam_rows, control_rows], ignore_index=True) if len(control_rows) else foam_rows.copy()
    summary, bins = summarize_fixed_anchor_twins(all_rows)
    verdict = _fixed_anchor_verdict(summary, bins, foam_label)

    result = {
        "verdict": verdict,
        "summary": summary,
        "bins": bins,
        "rows": all_rows,
        "foam_rows": foam_rows,
        "control_rows": control_rows,
        "selected_diamonds": diamonds,
        "control_sizes": sizes,
    }
    if out_dir is not None:
        out = Path(out_dir)
        out.mkdir(parents=True, exist_ok=True)
        all_rows.to_csv(out / f"fixed_anchor_twin_rows_{run_label}.csv", index=False)
        summary.to_csv(out / f"fixed_anchor_twin_summary_{run_label}.csv", index=False)
        bins.to_csv(out / f"fixed_anchor_twin_bins_{run_label}.csv", index=False)
        (out / f"fixed_anchor_twin_verdict_{run_label}.txt").write_text(verdict, encoding="utf-8")
        report = [f"# Fixed-anchor twin / time-dilation audit: {run_label}\n", "\n## Verdict\n", verdict]
        report.append("\n\n## Summary\n")
        report.append(summary.to_markdown(index=False) if len(summary) else "No summary.")
        report.append("\n\n## Velocity bins\n")
        report.append(bins.to_markdown(index=False) if len(bins) else "No bins.")
        (out / f"fixed_anchor_twin_report_{run_label}.md").write_text("\n".join(report), encoding="utf-8")
    return result


def plot_fixed_anchor_twin_bins(bins: pd.DataFrame, outfile: Optional[str] = None, models: Optional[Sequence[str]] = None):
    import matplotlib.pyplot as plt
    df = bins.copy()
    if models is not None:
        df = df[df["model"].isin(list(models))].copy()
    fig, ax = plt.subplots(figsize=(8, 5))
    for model, sub in df.groupby("model"):
        sub = sub.sort_values("v_target")
        ax.plot(sub["v_actual_med"], sub["tau_ratio_med"], marker="o", label=f"{model} measured")
    # Ideal curve for visual guide.
    xs = np.linspace(0, 0.85, 200)
    ax.plot(xs, np.sqrt(1 - xs * xs), linestyle="--", label="SR target sqrt(1-v^2)")
    ax.set_xlabel("median actual radar speed of fixed anchor C")
    ax.set_ylabel("moving/rest proper-time ratio")
    ax.set_title("Fixed-anchor A-C-B twin audit")
    ax.legend(fontsize=8)
    fig.tight_layout()
    if outfile:
        fig.savefig(outfile, dpi=180)
    return fig
