"""
Topological-slack / height-scaling audit for fixed-anchor SR twin tests.

Run after:
    %run -i deu_sr_fixed_anchor_twin_patch.py

Purpose
-------
The fixed-anchor A-C-B audit is the first observer-clock estimator that calibrates
on finite Minkowski controls, but the cap-512 foam at T~23 shows a much flatter
proper-time deficit than SR.  One hypothesis is finite-height/topological slack:
small irregular graphs let an anchored broken path satisfy a lateral offset while
losing only O(1) vertical hops.  If this is true, the measured deficit should
increase toward the SR target as T_rest_edges grows.

This patch adds:
    * fixed-anchor slack summaries by rest height T and target velocity
    * helpers to re-run fixed-anchor anchors on the tallest available foam diamonds
    * a bounded deep-foam helper for 20k/30k cap-512 tests

No geometry rules are changed.
"""
from __future__ import annotations

import math
from pathlib import Path
from typing import Dict, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


def _fass_require(name: str):
    if name not in globals():
        raise RuntimeError(
            f"Missing required name {name!r}. Run deu_sr_fixed_anchor_twin_patch.py "
            "and the SR fingerprint/minimal engine source first."
        )


def _fass_add_rest_heights(foam_result: Dict, diamonds: pd.DataFrame, max_rows: Optional[int] = None) -> pd.DataFrame:
    """Add T_rest_edges and strict interval height/volume columns to candidate diamonds."""
    _fass_require("_fa_interval_height_edges")
    rg2 = foam_result["rg2"]
    df = diamonds.copy().reset_index(drop=True)
    if max_rows is not None and len(df) > int(max_rows):
        # Prefer candidates already large by V if possible.
        sort_col = "V" if "V" in df.columns else "V_strict_prescan" if "V_strict_prescan" in df.columns else None
        if sort_col is not None:
            df = df.sort_values(sort_col, ascending=False).head(int(max_rows)).reset_index(drop=True)
        else:
            df = df.head(int(max_rows)).reset_index(drop=True)
    hs = []
    es = []
    vols = []
    for row in df.itertuples(index=False):
        try:
            a = int(getattr(row, "a_index"))
            b = int(getattr(row, "b_index"))
            h, e, v = _fa_interval_height_edges(rg2, a, b)
        except Exception:
            h, e, v = np.nan, np.nan, np.nan
        hs.append(h); es.append(e); vols.append(v)
    df["h_rest_inclusive_exact"] = hs
    df["T_rest_edges_exact"] = es
    if "V" not in df.columns:
        df["V"] = vols
    return df


def select_tall_foam_diamonds_for_fixed_anchor(
    foam_result: Dict,
    selected_gap_bins: Optional[Sequence[int]] = None,
    min_T_rest_edges: int = 0,
    max_candidates_before_height: int = 3000,
    max_intervals: int = 80,
    prefer_sr_window: bool = True,
) -> pd.DataFrame:
    """
    Select the tallest available diamonds from a foam_result for fixed-anchor tests.

    If selected_gap_bins is None and prefer_sr_window=True, uses foam_result['selected_gap_bins'].
    Set selected_gap_bins=None and prefer_sr_window=False to scan all sampled diamonds.
    """
    if "diamonds" not in foam_result:
        raise ValueError("foam_result must contain a 'diamonds' DataFrame.")
    df = foam_result["diamonds"].copy()
    if "V" not in df.columns:
        if "V_strict_prescan" in df.columns:
            df["V"] = df["V_strict_prescan"]
        elif "interval_bits" in df.columns:
            df["V"] = df["interval_bits"].map(lambda x: int(x).bit_count())
    if selected_gap_bins is None and prefer_sr_window:
        selected_gap_bins = foam_result.get("selected_gap_bins", None)
    if selected_gap_bins is not None and "gap_bin" in df.columns:
        df = df[df["gap_bin"].isin(list(selected_gap_bins))].copy()
    if len(df) == 0:
        raise ValueError("No diamonds after gap-bin filter.")
    df = _fass_add_rest_heights(foam_result, df, max_rows=int(max_candidates_before_height))
    df = df[np.isfinite(df["T_rest_edges_exact"])].copy()
    df = df[df["T_rest_edges_exact"] >= int(min_T_rest_edges)].copy()
    if len(df) == 0:
        raise ValueError("No diamonds satisfy min_T_rest_edges. Try lowering the threshold or using all gap bins.")
    df = df.sort_values(["T_rest_edges_exact", "V"], ascending=[False, False]).head(int(max_intervals)).reset_index(drop=True)
    return df


def summarize_fixed_anchor_topological_slack(
    rows: pd.DataFrame,
    model: Optional[str] = None,
    T_bins: Optional[Sequence[float]] = None,
    min_v_for_high_speed: float = 0.55,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Summarize how much of the SR proper-time deficit is captured.

    deficit_capture = (1 - tau_ratio_measured) / (1 - tau_ratio_pred)
      0 means no time-dilation deficit was captured.
      1 means the SR predicted deficit was captured exactly.
      >1 means over-dilation relative to the prediction.

    slack_edges = tau_moving_edges - tau_pred_cont
      positive means the graph path retains extra proper time relative to SR.
    """
    if rows is None or len(rows) == 0:
        return pd.DataFrame(), pd.DataFrame()
    ok = rows[rows.get("status", "ok") == "ok"].copy()
    if model is not None:
        ok = ok[ok["model"] == model].copy()
    if len(ok) == 0:
        return pd.DataFrame(), pd.DataFrame()

    ok["sr_deficit_pred"] = 1.0 - ok["tau_ratio_pred"].astype(float)
    ok["sr_deficit_measured"] = 1.0 - ok["tau_ratio_measured"].astype(float)
    ok["deficit_capture"] = ok["sr_deficit_measured"] / ok["sr_deficit_pred"].replace(0, np.nan)
    ok["slack_edges"] = ok["tau_moving_edges"].astype(float) - ok["tau_pred_cont"].astype(float)
    ok["slack_frac_of_T"] = ok["slack_edges"] / ok["T_rest_edges"].replace(0, np.nan).astype(float)
    ok["high_speed"] = ok["v_actual"].astype(float) >= float(min_v_for_high_speed)

    # Per velocity bin.
    by_v = []
    for (m, vt), sub in ok.groupby(["model", "v_target"], dropna=False):
        by_v.append({
            "model": str(m),
            "v_target": float(vt),
            "n": int(len(sub)),
            "T_med": float(np.nanmedian(sub["T_rest_edges"])),
            "T_min": float(np.nanmin(sub["T_rest_edges"])),
            "T_max": float(np.nanmax(sub["T_rest_edges"])),
            "v_actual_med": float(np.nanmedian(sub["v_actual"])),
            "tau_ratio_med": float(np.nanmedian(sub["tau_ratio_measured"])),
            "tau_ratio_pred_med": float(np.nanmedian(sub["tau_ratio_pred"])),
            "gamma_med": float(np.nanmedian(sub["gamma_measured"])),
            "gamma_pred_med": float(np.nanmedian(sub["gamma_pred"])),
            "deficit_capture_med": float(np.nanmedian(sub["deficit_capture"])),
            "deficit_capture_q25": float(np.nanquantile(sub["deficit_capture"], 0.25)),
            "deficit_capture_q75": float(np.nanquantile(sub["deficit_capture"], 0.75)),
            "slack_edges_med": float(np.nanmedian(sub["slack_edges"])),
            "slack_frac_of_T_med": float(np.nanmedian(sub["slack_frac_of_T"])),
            "segment_min_edges_med": float(np.nanmedian(np.minimum(sub["tau_AC_edges"], sub["tau_CB_edges"]))),
        })
    by_v = pd.DataFrame(by_v).sort_values(["model", "v_target"]).reset_index(drop=True)

    # By T bins, with high-speed subset emphasized.
    if T_bins is None:
        T = ok["T_rest_edges"].to_numpy(dtype=float)
        if len(np.unique(T[np.isfinite(T)])) >= 4:
            qs = np.unique(np.nanquantile(T, [0, .25, .5, .75, 1.0]))
            if len(qs) >= 3:
                # Expand ends slightly for cut inclusion.
                qs[0] -= 1e-9; qs[-1] += 1e-9
                T_bins = qs
            else:
                T_bins = None
    by_T = pd.DataFrame()
    if T_bins is not None:
        tmp = ok.copy()
        tmp["T_bin"] = pd.cut(tmp["T_rest_edges"].astype(float), bins=list(T_bins), include_lowest=True)
        rows_T = []
        for (m, tb, hs), sub in tmp.groupby(["model", "T_bin", "high_speed"], dropna=False):
            if len(sub) == 0:
                continue
            rows_T.append({
                "model": str(m),
                "T_bin": str(tb),
                "high_speed": bool(hs),
                "n": int(len(sub)),
                "T_med": float(np.nanmedian(sub["T_rest_edges"])),
                "v_actual_med": float(np.nanmedian(sub["v_actual"])),
                "deficit_capture_med": float(np.nanmedian(sub["deficit_capture"])),
                "slack_edges_med": float(np.nanmedian(sub["slack_edges"])),
                "slack_frac_of_T_med": float(np.nanmedian(sub["slack_frac_of_T"])),
                "gamma_rel_err_med": float(np.nanmedian(sub["gamma_rel_err"])),
            })
        by_T = pd.DataFrame(rows_T).sort_values(["model", "high_speed", "T_med"]).reset_index(drop=True)
    return by_v, by_T


def interpret_topological_slack_scale(by_v: pd.DataFrame, by_T: pd.DataFrame, model: str) -> str:
    """Conservative, falsification-oriented interpretation."""
    if by_v is None or len(by_v) == 0:
        return "NO RESULT: no usable fixed-anchor rows."
    m = by_v[by_v["model"] == model].copy()
    if len(m) == 0:
        return f"NO RESULT: model {model!r} missing from slack summary."
    Tmax = float(np.nanmax(m["T_max"]))
    high = m[m["v_target"].astype(float) >= 0.55]
    cap_med = float(np.nanmedian(high["deficit_capture_med"])) if len(high) else np.nan
    slack_frac = float(np.nanmedian(high["slack_frac_of_T_med"])) if len(high) else np.nan
    pieces = [f"max T_rest_edges={Tmax:.1f}"]
    if np.isfinite(cap_med):
        pieces.append(f"high-v deficit_capture_med={cap_med:.3f}")
    if np.isfinite(slack_frac):
        pieces.append(f"high-v slack_frac_of_T_med={slack_frac:.3f}")
    if Tmax < 40:
        return "HEIGHT-LIMITED: current foam anchors are too short to decide the topological-slack hypothesis. " + "; ".join(pieces)
    if np.isfinite(cap_med) and cap_med >= 0.60:
        return "PROMISING: larger fixed-anchor diamonds capture a substantial fraction of the SR time-dilation deficit. " + "; ".join(pieces)
    if np.isfinite(cap_med) and cap_med < 0.35:
        return "NOT YET PASSING: even larger anchors still retain too much topological slack. " + "; ".join(pieces)
    return "MIXED: larger anchors show some deficit but not a clean SR curve yet. " + "; ".join(pieces)


def run_fixed_anchor_slack_scale_from_foam_result(
    foam_result: Dict,
    foam_label: str = "foam_cap512_SR_window",
    selected_gap_bins: Optional[Sequence[int]] = None,
    prefer_sr_window: bool = True,
    max_intervals: int = 80,
    min_T_rest_edges: int = 0,
    v_targets: Sequence[float] = (0.0, 0.2, 0.4, 0.6, 0.75),
    v_band: float = 0.10,
    mid_t_band: float = 0.10,
    run_label: str = "slack_scale",
    out_dir: Optional[Path] = None,
) -> Dict:
    """Re-run fixed-anchor rows on the tallest selected foam diamonds and summarize slack."""
    _fass_require("fixed_anchor_twin_rows_for_diamonds")
    _fass_require("summarize_fixed_anchor_twins")
    diamonds = select_tall_foam_diamonds_for_fixed_anchor(
        foam_result,
        selected_gap_bins=selected_gap_bins,
        min_T_rest_edges=int(min_T_rest_edges),
        max_intervals=int(max_intervals),
        prefer_sr_window=bool(prefer_sr_window),
    )
    rows = fixed_anchor_twin_rows_for_diamonds(
        foam_result["rg2"],
        diamonds,
        foam_label,
        v_targets=v_targets,
        v_band=float(v_band),
        mid_t_band=float(mid_t_band),
    )
    summary, bins = summarize_fixed_anchor_twins(rows)
    by_v, by_T = summarize_fixed_anchor_topological_slack(rows, model=foam_label)
    verdict = interpret_topological_slack_scale(by_v, by_T, foam_label)
    result = {
        "verdict": verdict,
        "selected_diamonds": diamonds,
        "rows": rows,
        "summary": summary,
        "bins": bins,
        "slack_by_velocity": by_v,
        "slack_by_T": by_T,
    }
    if out_dir is not None:
        out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
        diamonds.to_csv(out / f"fixed_anchor_slack_selected_diamonds_{run_label}.csv", index=False)
        rows.to_csv(out / f"fixed_anchor_slack_rows_{run_label}.csv", index=False)
        summary.to_csv(out / f"fixed_anchor_slack_summary_{run_label}.csv", index=False)
        bins.to_csv(out / f"fixed_anchor_slack_bins_{run_label}.csv", index=False)
        by_v.to_csv(out / f"fixed_anchor_slack_by_velocity_{run_label}.csv", index=False)
        by_T.to_csv(out / f"fixed_anchor_slack_by_T_{run_label}.csv", index=False)
        (out / f"fixed_anchor_slack_verdict_{run_label}.txt").write_text(verdict, encoding="utf-8")
    return result


def run_cap512_deep_sr_then_slack_test(
    target_basin_splits: int = 30000,
    cap: int = 512,
    seed: int = 101,
    ep_lo: Optional[int] = 9,
    ep_hi: Optional[int] = None,
    gap_bins: Sequence[Tuple[int, int]] = ((4, 8), (8, 12), (12, 16), (16, 24), (24, 32), (32, 48), (48, 64)),
    n_endpoint_samples_per_bin: int = 8000,
    keep_top_per_bin: int = 80,
    max_intervals: int = 80,
    min_T_rest_edges: int = 30,
    run_label: str = "cap512_deep_slack",
    out_dir: Optional[Path] = None,
) -> Dict:
    """
    Convenience helper: generate a deeper cap-512 SR sample and run the slack test.

    This can be expensive. Start with target_basin_splits=20000 and samples/bin=3000
    if you want a smoke test.
    """
    _fass_require("run_foam_sr_sample")
    foam = run_foam_sr_sample(
        cap=int(cap),
        seed=int(seed),
        target_basin_splits=int(target_basin_splits),
        ep_lo=ep_lo,
        ep_hi=ep_hi,
        gap_bins=gap_bins,
        n_endpoint_samples_per_bin=int(n_endpoint_samples_per_bin),
        keep_top_per_bin=int(keep_top_per_bin),
        n_profile_bins=21,
        choose_window=True,
    )
    slack = run_fixed_anchor_slack_scale_from_foam_result(
        foam,
        foam_label=f"foam_cap{cap}_SR_window",
        selected_gap_bins=foam.get("selected_gap_bins"),
        prefer_sr_window=True,
        max_intervals=int(max_intervals),
        min_T_rest_edges=int(min_T_rest_edges),
        run_label=run_label,
        out_dir=out_dir,
    )
    return {"foam_result": foam, "slack_result": slack}
