"""
SR Lorentz/radar-coordinate audit for DEU triangular foam.

Run after the SR fingerprint notebook has loaded:
    %run -i src/deu_exp456_minimal.py
    %run -i src/deu_exp456_overflow_patch.py
    %run -i src/deu_sr_fingerprint.py

Typical use after building foam_result_512:
    %run -i deu_sr_lorentz_radar_patch.py
    lorentz_512 = run_lorentz_radar_audit_from_foam_result(
        foam_result_512,
        foam_label="foam_cap512_SR_window",
        max_foam_intervals=80,
        control_reps=40,
        seed=51277,
        run_label="cap512"
    )
    lorentz_512["summary"]
    lorentz_512["verdict"]

This audit is deliberately graph-internal. It chooses a longest chain inside each
causal diamond as an observer clock, assigns radar coordinates to events using
causal precedence with that chain, and tests the SR relations
    tau^2 ~ t^2 - r^2
    gamma = t/tau ~ 1/sqrt(1-v^2), v=r/t
plus a light-cone-boundary check that near-null/low-volume events sit closer to
v=1 than bulk events.

Caveat: this is a finite causal-set/radar-coordinate screen, not a proof of exact
Lorentz invariance. Length contraction requires stable rods/worldtubes and is not
claimed here.
"""
from __future__ import annotations

import math
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


def _bit_is_set(bits: int, i: int) -> bool:
    return bool(int(bits) & (1 << int(i)))


def _precedes_or_equal(causet, i: int, j: int) -> bool:
    """Return i <= j in the causet."""
    i = int(i); j = int(j)
    return i == j or _bit_is_set(causet.ancestor_bits[j], i)


def _extract_longest_chain_from_interval(causet, inclusive_bits: int, a_index: int, b_index: int) -> List[int]:
    """
    Extract one longest chain from a to b inside inclusive_bits by backtracking ranks.
    Assumes a_index and b_index are included and a_index <= b_index.
    """
    inclusive_bits = int(inclusive_bits)
    ranks, layers, height = longest_chain_layers_bits(causet, inclusive_bits)
    a_index = int(a_index); b_index = int(b_index)
    if b_index not in ranks or a_index not in ranks or height <= 0:
        return []
    chain = [b_index]
    current = b_index
    current_rank = int(ranks[current])
    while current_rank > 1:
        prev_bits = causet.ancestor_bits[current] & inclusive_bits
        candidates = [j for j in iter_bits(prev_bits) if int(ranks.get(j, -1)) == current_rank - 1]
        if not candidates:
            # Fall back to any element in previous layer, but this should almost never happen.
            candidates = [j for j, r in ranks.items() if int(r) == current_rank - 1]
            if not candidates:
                break
        # Prefer the candidate with the largest number of descendants inside the remaining interval.
        # This tends to choose a central-ish geodesic rather than a dangling one.
        current = max(candidates, key=lambda j: int((causet.descendant_bits[j] & inclusive_bits).bit_count()))
        chain.append(int(current))
        current_rank -= 1
    chain = list(reversed(chain))
    if chain and chain[0] != a_index:
        # If the extracted chain starts at another rank-1 element, force endpoint if valid.
        if _precedes_or_equal(causet, a_index, chain[0]):
            chain[0] = a_index
    if chain and chain[-1] != b_index:
        chain[-1] = b_index
    # Remove accidental duplicates while preserving order.
    out = []
    seen = set()
    for x in chain:
        if x not in seen:
            out.append(int(x)); seen.add(int(x))
    return out


def radar_coordinates_for_interval(
    causet,
    strict_bits: int,
    a_index: int,
    b_index: int,
    interval_id: str = "interval",
    model: str = "model",
    min_t: float = 2.0,
) -> Tuple[pd.DataFrame, Dict[str, float]]:
    """
    Assign graph radar coordinates to events in a causal diamond.

    Observer clock: one longest chain from a to b. Observer time is chain index.
    For event x:
      p = latest observer tick that precedes x
      q = earliest observer tick that x precedes
      t = (p + q)/2
      r = (q - p)/2
      tau = longest-chain height from a to x, measured in tick units.

    Continuum SR in radial coordinates predicts tau^2 = t^2 - r^2 and
    gamma = t/tau = 1/sqrt(1-(r/t)^2), modulo finite-size/scale noise.
    """
    strict_bits = int(strict_bits)
    a_index = int(a_index); b_index = int(b_index)
    inclusive_bits = strict_bits | bit_at(a_index) | bit_at(b_index)
    ranks, layers, height = longest_chain_layers_bits(causet, inclusive_bits)
    chain = _extract_longest_chain_from_interval(causet, inclusive_bits, a_index, b_index)
    H = len(chain)
    if H < 4:
        return pd.DataFrame(), {"interval_id": interval_id, "model": model, "status": "no_observer_chain", "observer_height": H}

    rows = []
    # Include strict events plus top for diagnostics, exclude bottom from fit.
    event_bits = strict_bits | bit_at(b_index)
    for x in iter_bits(event_bits):
        x = int(x)
        # Latest observer element in past of x, earliest observer element in future of x.
        p = None; q = None
        for k, oi in enumerate(chain):
            if _precedes_or_equal(causet, oi, x):
                p = k
            if q is None and _precedes_or_equal(causet, x, oi):
                q = k
        if p is None or q is None or q < p:
            continue
        t = 0.5 * (p + q)
        r = 0.5 * (q - p)
        tau = float(ranks.get(x, np.nan) - 1)  # bottom has tau=0, top has tau~H-1
        if not np.isfinite(tau) or tau <= 0 or t <= 0:
            continue
        v = r / t if t > 0 else np.nan
        inv = t * t - r * r
        gamma_measured = t / tau if tau > 0 else np.nan
        gamma_pred = 1.0 / math.sqrt(max(1e-12, 1.0 - v * v)) if np.isfinite(v) and v < 1 else np.nan
        # Strict interval volume between bottom a and x: a near-null proxy.
        subV = int((causet.descendant_bits[a_index] & causet.ancestor_bits[x]).bit_count()) if x != a_index else 0
        rows.append({
            "model": model,
            "interval_id": interval_id,
            "event_index": x,
            "is_top": bool(x == b_index),
            "observer_height": H,
            "interval_height": int(height),
            "p_tick": int(p),
            "q_tick": int(q),
            "t_radar": float(t),
            "r_radar": float(r),
            "v_radar": float(v) if np.isfinite(v) else np.nan,
            "tau_chain": float(tau),
            "tau2_chain": float(tau * tau),
            "minkowski_inv": float(inv),
            "gamma_measured": float(gamma_measured) if np.isfinite(gamma_measured) else np.nan,
            "gamma_pred": float(gamma_pred) if np.isfinite(gamma_pred) else np.nan,
            "subV_from_bottom": int(subV),
            "on_observer": bool(p == q),
        })
    df = pd.DataFrame(rows)
    meta = {
        "interval_id": interval_id,
        "model": model,
        "status": "ok" if len(df) else "no_events",
        "observer_height": int(H),
        "interval_height": int(height),
        "V_strict": int(strict_bits.bit_count()),
        "n_radar_events": int(len(df)),
    }
    return df, meta


def _linear_fit_y_on_x(x, y, min_points: int = 8) -> Dict[str, float]:
    x = np.asarray(x, dtype=float); y = np.asarray(y, dtype=float)
    m = np.isfinite(x) & np.isfinite(y)
    x = x[m]; y = y[m]
    if len(x) < min_points:
        return {"slope": np.nan, "intercept": np.nan, "r2": np.nan, "n_fit": int(len(x))}
    slope, intercept = np.polyfit(x, y, 1)
    pred = intercept + slope * x
    ss_res = float(np.sum((y - pred) ** 2))
    ss_tot = float(np.sum((y - y.mean()) ** 2))
    r2 = np.nan if ss_tot <= 0 else 1.0 - ss_res / ss_tot
    return {"slope": float(slope), "intercept": float(intercept), "r2": float(r2), "n_fit": int(len(x))}


def summarize_radar_events(radar_df: pd.DataFrame, model: str) -> Dict[str, float]:
    if radar_df is None or len(radar_df) == 0:
        return {"model": model, "status": "empty"}
    df = radar_df.copy()
    fit = df[
        (~df["is_top"])
        & (~df["on_observer"])
        & np.isfinite(df["v_radar"])
        & (df["v_radar"] > 0.05)
        & (df["v_radar"] < 0.97)
        & (df["t_radar"] >= 2.0)
        & (df["tau_chain"] >= 1.0)
        & (df["minkowski_inv"] > 0)
    ].copy()

    inv_fit = _linear_fit_y_on_x(fit["minkowski_inv"], fit["tau2_chain"], min_points=20)
    gam = fit[np.isfinite(fit["gamma_measured"]) & np.isfinite(fit["gamma_pred"])].copy()
    gamma_fit = _linear_fit_y_on_x(gam["gamma_pred"], gam["gamma_measured"], min_points=20)
    if len(gam):
        gam_rel = np.abs(gam["gamma_measured"] - gam["gamma_pred"]) / np.maximum(1e-9, gam["gamma_pred"])
        gamma_rel_err_med = float(np.nanmedian(gam_rel))
        gamma_rel_err_q80 = float(np.nanquantile(gam_rel, 0.80))
        gamma_corr = float(np.corrcoef(gam["gamma_pred"], gam["gamma_measured"])[0,1]) if len(gam) >= 3 else np.nan
    else:
        gamma_rel_err_med = gamma_rel_err_q80 = gamma_corr = np.nan

    # Light-cone proxy: events with very small bottom interval volume should have high radar speed.
    lc = fit.copy()
    if len(lc) >= 20 and lc["subV_from_bottom"].nunique() > 2:
        q15 = float(lc["subV_from_bottom"].quantile(0.15))
        q50 = float(lc["subV_from_bottom"].quantile(0.50))
        near = lc[lc["subV_from_bottom"] <= q15]
        bulk = lc[lc["subV_from_bottom"] >= q50]
        near_v = float(near["v_radar"].median()) if len(near) else np.nan
        bulk_v = float(bulk["v_radar"].median()) if len(bulk) else np.nan
        near_frac_gt_08 = float((near["v_radar"] > 0.8).mean()) if len(near) else np.nan
        lightcone_margin = near_v - bulk_v if np.isfinite(near_v) and np.isfinite(bulk_v) else np.nan
        n_near = int(len(near)); n_bulk = int(len(bulk))
    else:
        q15 = q50 = near_v = bulk_v = near_frac_gt_08 = lightcone_margin = np.nan
        n_near = n_bulk = 0

    return {
        "model": model,
        "status": "ok",
        "n_intervals": int(df["interval_id"].nunique()),
        "n_events_total": int(len(df)),
        "n_events_fit": int(len(fit)),
        "observer_height_med": float(df.groupby("interval_id")["observer_height"].first().median()),
        "v_median": float(np.nanmedian(fit["v_radar"])) if len(fit) else np.nan,
        "v_q90": float(np.nanquantile(fit["v_radar"], 0.90)) if len(fit) else np.nan,
        "invariant_slope_tau2_vs_t2minusr2": inv_fit["slope"],
        "invariant_intercept": inv_fit["intercept"],
        "invariant_r2": inv_fit["r2"],
        "invariant_n_fit": inv_fit["n_fit"],
        "gamma_slope_measured_vs_pred": gamma_fit["slope"],
        "gamma_intercept": gamma_fit["intercept"],
        "gamma_r2": gamma_fit["r2"],
        "gamma_corr": gamma_corr,
        "gamma_rel_err_median": gamma_rel_err_med,
        "gamma_rel_err_q80": gamma_rel_err_q80,
        "gamma_n_fit": int(len(gam)),
        "lightcone_subV_q15": q15,
        "lightcone_subV_q50": q50,
        "lightcone_near_v_median": near_v,
        "lightcone_bulk_v_median": bulk_v,
        "lightcone_margin_near_minus_bulk": lightcone_margin,
        "lightcone_near_frac_v_gt_0p8": near_frac_gt_08,
        "lightcone_n_near": n_near,
        "lightcone_n_bulk": n_bulk,
    }


def _audit_many_diamonds(causet, diamond_rows: pd.DataFrame, model: str, max_intervals: int = 80) -> Tuple[pd.DataFrame, pd.DataFrame]:
    rows = []
    metas = []
    if diamond_rows is None or len(diamond_rows) == 0:
        return pd.DataFrame(), pd.DataFrame()
    df = diamond_rows.copy()
    # Favor large intervals but keep deterministic ordering.
    sort_cols = [c for c in ["V", "V_strict_prescan", "size", "h_med"] if c in df.columns]
    if "V" not in df.columns and "V_strict_prescan" in df.columns:
        df["V"] = df["V_strict_prescan"]
    if "V" in df.columns:
        df = df.sort_values("V", ascending=False)
    df = df.head(int(max_intervals)).copy()
    for k, row in enumerate(df.itertuples(index=False)):
        strict_bits = int(getattr(row, "interval_bits"))
        a = int(getattr(row, "a_index"))
        b = int(getattr(row, "b_index"))
        rid = f"{model}_d{k}"
        ev, meta = radar_coordinates_for_interval(causet, strict_bits, a, b, interval_id=rid, model=model)
        if len(ev):
            # Attach original diamond metadata where available.
            for col in ["gap_bin", "gap_lo", "gap_hi", "epoch_gap", "ep_a", "ep_b"]:
                if hasattr(row, col):
                    ev[col] = getattr(row, col)
                    meta[col] = getattr(row, col)
            rows.append(ev)
        metas.append(meta)
    if rows:
        return pd.concat(rows, ignore_index=True), pd.DataFrame(metas)
    return pd.DataFrame(), pd.DataFrame(metas)


def build_control_radar_samples(
    sizes: Sequence[int],
    reps_per_size: int = 4,
    seed: int = 12345,
    models: Sequence[str] = ("minkowski_2p1D", "minkowski_3p1D", "random_DAG", "chain_1D"),
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    all_events = []
    all_meta = []
    rng = np.random.default_rng(seed)
    for n in sizes:
        n = int(max(8, n))
        if "chain_1D" in models:
            c, a, b = make_chain_interval_causet(n)
            ev, meta = radar_coordinates_for_interval(c, c.descendant_bits[a] & c.ancestor_bits[b], a, b, interval_id=f"chain_n{n}", model="chain_1D")
            if len(ev): all_events.append(ev)
            all_meta.append(meta)
        for rep in range(int(reps_per_size)):
            base = int(seed + 100000 * rep + 97 * n)
            if "minkowski_2p1D" in models:
                c, a, b = make_minkowski_interval_causet(n, d=3, seed=base + 3)
                ev, meta = radar_coordinates_for_interval(c, c.descendant_bits[a] & c.ancestor_bits[b], a, b, interval_id=f"minkowski_2p1D_n{n}_r{rep}", model="minkowski_2p1D")
                if len(ev): all_events.append(ev)
                all_meta.append(meta)
            if "minkowski_3p1D" in models:
                c, a, b = make_minkowski_interval_causet(n, d=4, seed=base + 4)
                ev, meta = radar_coordinates_for_interval(c, c.descendant_bits[a] & c.ancestor_bits[b], a, b, interval_id=f"minkowski_3p1D_n{n}_r{rep}", model="minkowski_3p1D")
                if len(ev): all_events.append(ev)
                all_meta.append(meta)
            if "random_DAG" in models:
                c, a, b = make_random_dag_interval_causet(n, p=0.025, seed=base + 999)
                ev, meta = radar_coordinates_for_interval(c, c.descendant_bits[a] & c.ancestor_bits[b], a, b, interval_id=f"random_DAG_n{n}_r{rep}", model="random_DAG")
                if len(ev): all_events.append(ev)
                all_meta.append(meta)
    events = pd.concat(all_events, ignore_index=True) if all_events else pd.DataFrame()
    meta = pd.DataFrame(all_meta)
    return events, meta


def run_lorentz_radar_audit_from_foam_result(
    foam_result: Dict,
    foam_label: str = "foam_SR_window",
    selected_gap_bins: Optional[Sequence[int]] = None,
    max_foam_intervals: int = 80,
    control_reps: int = 8,
    n_control_sizes: int = 8,
    seed: int = 777,
    run_label: str = "lorentz",
    out_dir: Optional[Path | str] = None,
) -> Dict[str, object]:
    """
    Run radar-coordinate SR tests on a selected foam window plus matched controls.
    Reuses a completed foam_result returned by run_foam_sr_sample.
    """
    rg2 = foam_result["rg2"]
    diamonds = foam_result["diamonds"].copy()
    if selected_gap_bins is None:
        selected_gap_bins = foam_result.get("selected_gap_bins", None)
    if selected_gap_bins is not None and "gap_bin" in diamonds.columns:
        diamonds = diamonds[diamonds["gap_bin"].isin(list(selected_gap_bins))].copy()
    if len(diamonds) == 0:
        raise ValueError("No diamonds after selected_gap_bins filter.")
    if "V" not in diamonds.columns:
        if "V_strict_prescan" in diamonds.columns:
            diamonds["V"] = diamonds["V_strict_prescan"]
        else:
            diamonds["V"] = diamonds["interval_bits"].map(lambda x: int(x).bit_count())

    foam_events, foam_meta = _audit_many_diamonds(rg2, diamonds, model=foam_label, max_intervals=max_foam_intervals)

    # Match controls to the selected foam volumes with quantile-spaced sizes.
    Vvals = diamonds["V"].astype(float).to_numpy()
    qs = np.linspace(0.10, 0.90, int(n_control_sizes))
    sizes = sorted(set(int(max(20, round(np.nanquantile(Vvals, q)))) for q in qs))
    control_events, control_meta = build_control_radar_samples(sizes=sizes, reps_per_size=control_reps, seed=seed)

    combined_events = pd.concat([foam_events, control_events], ignore_index=True) if len(control_events) else foam_events.copy()
    summaries = []
    for model, sub in combined_events.groupby("model", dropna=False):
        summaries.append(summarize_radar_events(sub, str(model)))
    summary = pd.DataFrame(summaries)
    # Helpful ordering.
    order = {foam_label: 0, "minkowski_2p1D": 1, "minkowski_3p1D": 2, "random_DAG": 3, "chain_1D": 4}
    if len(summary):
        summary["_ord"] = summary["model"].map(order).fillna(99)
        summary = summary.sort_values(["_ord", "model"]).drop(columns=["_ord"]).reset_index(drop=True)

    verdict = interpret_lorentz_radar_summary(summary, foam_label=foam_label)

    result = {
        "summary": summary,
        "events": combined_events,
        "foam_events": foam_events,
        "control_events": control_events,
        "foam_meta": foam_meta,
        "control_meta": control_meta,
        "control_sizes": sizes,
        "selected_gap_bins": tuple(selected_gap_bins) if selected_gap_bins is not None else None,
        "verdict": verdict,
    }
    if out_dir is not None:
        out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
        summary.to_csv(out / f"lorentz_radar_summary_{run_label}.csv", index=False)
        combined_events.to_csv(out / f"lorentz_radar_events_{run_label}.csv", index=False)
        foam_meta.to_csv(out / f"lorentz_radar_foam_meta_{run_label}.csv", index=False)
        control_meta.to_csv(out / f"lorentz_radar_control_meta_{run_label}.csv", index=False)
        (out / f"lorentz_radar_verdict_{run_label}.txt").write_text(verdict, encoding="utf-8")
    return result


def interpret_lorentz_radar_summary(summary: pd.DataFrame, foam_label: str = "foam_SR_window") -> str:
    if summary is None or len(summary) == 0 or foam_label not in set(summary["model"]):
        return "UNDETERMINED: no foam radar summary found."
    row = summary[summary["model"] == foam_label].iloc[0]
    inv_ok = bool(row.get("invariant_r2", np.nan) >= 0.75)
    gam_ok = bool(row.get("gamma_rel_err_median", np.inf) <= 0.35)
    lc_ok = bool(row.get("lightcone_margin_near_minus_bulk", -np.inf) > 0.05)
    n_ok = bool(row.get("n_events_fit", 0) >= 100)
    pieces = []
    if inv_ok: pieces.append("radar invariant tau^2 ~ t^2-r^2 is coherent")
    if gam_ok: pieces.append("Lorentz-factor relation is within finite-sample tolerance")
    if lc_ok: pieces.append("near-null events sit closer to v=1 than bulk events")
    if n_ok: pieces.append("sample is non-tiny")
    if inv_ok and gam_ok and lc_ok and n_ok:
        return "PASS / PROMISING: graph radar coordinates recover SR-like invariant, Lorentz-factor, and light-cone-boundary behavior over the selected foam window."
    if inv_ok and (gam_ok or lc_ok) and n_ok:
        return "PARTIAL PASS: radar invariant is coherent and at least one SR subtest passes, but this is supporting evidence rather than a full SR kinematics result."
    return "NOT YET PASSING: graph radar-coordinate SR tests are weak or under-sampled. Treat MM/SR-fingerprint success as interval-statistical, not as Lorentz-factor derivation."


def plot_gamma_relation(events: pd.DataFrame, outfile: Optional[str] = None, models: Optional[Sequence[str]] = None, max_points_per_model: int = 2500):
    import matplotlib.pyplot as plt
    df = events.copy()
    if models is not None:
        df = df[df["model"].isin(list(models))].copy()
    df = df[(df["v_radar"] > 0.05) & (df["v_radar"] < 0.97) & np.isfinite(df["gamma_measured"]) & np.isfinite(df["gamma_pred"])].copy()
    fig, ax = plt.subplots(figsize=(6.5, 5.0))
    rng = np.random.default_rng(123)
    for model, sub in df.groupby("model"):
        if len(sub) > max_points_per_model:
            sub = sub.sample(max_points_per_model, random_state=123)
        ax.scatter(sub["gamma_pred"], sub["gamma_measured"], s=8, alpha=0.35, label=str(model))
    lo, hi = 1.0, float(np.nanquantile(df[["gamma_pred", "gamma_measured"]].to_numpy().ravel(), 0.98)) if len(df) else 3.0
    hi = max(1.2, min(hi, 6.0))
    ax.plot([lo, hi], [lo, hi], linewidth=1.5)
    ax.set_xlabel(r"predicted $\gamma=1/\sqrt{1-v^2}$")
    ax.set_ylabel(r"measured $\gamma=t/\tau$")
    ax.set_title("Graph radar Lorentz-factor test")
    ax.legend(fontsize=8)
    fig.tight_layout()
    if outfile:
        fig.savefig(outfile, dpi=180)
    return fig, ax


def plot_invariant_relation(events: pd.DataFrame, outfile: Optional[str] = None, models: Optional[Sequence[str]] = None, max_points_per_model: int = 2500):
    import matplotlib.pyplot as plt
    df = events.copy()
    if models is not None:
        df = df[df["model"].isin(list(models))].copy()
    df = df[(df["minkowski_inv"] > 0) & np.isfinite(df["tau2_chain"])].copy()
    fig, ax = plt.subplots(figsize=(6.5, 5.0))
    for model, sub in df.groupby("model"):
        if len(sub) > max_points_per_model:
            sub = sub.sample(max_points_per_model, random_state=456)
        ax.scatter(sub["minkowski_inv"], sub["tau2_chain"], s=8, alpha=0.35, label=str(model))
    lo = 0.0
    hi = float(np.nanquantile(df[["minkowski_inv", "tau2_chain"]].to_numpy().ravel(), 0.98)) if len(df) else 10.0
    ax.plot([lo, hi], [lo, hi], linewidth=1.5)
    ax.set_xlabel(r"radar invariant $t^2-r^2$")
    ax.set_ylabel(r"chain proper time $\tau^2$")
    ax.set_title("Graph radar invariant test")
    ax.legend(fontsize=8)
    fig.tight_layout()
    if outfile:
        fig.savefig(outfile, dpi=180)
    return fig, ax


def plot_lightcone_proxy(events: pd.DataFrame, outfile: Optional[str] = None, models: Optional[Sequence[str]] = None):
    import matplotlib.pyplot as plt
    df = events.copy()
    if models is not None:
        df = df[df["model"].isin(list(models))].copy()
    df = df[(df["v_radar"] >= 0) & (df["v_radar"] < 1) & np.isfinite(df["subV_from_bottom"])].copy()
    # Bin by subV quantile within each model.
    rows = []
    for model, sub in df.groupby("model"):
        sub = sub.copy()
        if len(sub) < 20 or sub["subV_from_bottom"].nunique() < 3:
            continue
        sub["subV_quantile_bin"] = pd.qcut(sub["subV_from_bottom"].rank(method="first"), q=5, labels=False, duplicates="drop")
        for b, ss in sub.groupby("subV_quantile_bin"):
            rows.append({"model": model, "subV_quantile_bin": int(b), "v_median": float(ss["v_radar"].median()), "n": int(len(ss))})
    qdf = pd.DataFrame(rows)
    fig, ax = plt.subplots(figsize=(6.5, 4.5))
    for model, sub in qdf.groupby("model"):
        ax.plot(sub["subV_quantile_bin"], sub["v_median"], marker="o", label=str(model))
    ax.set_xlabel("bottom-interval-volume quantile (low = near-null proxy)")
    ax.set_ylabel("median radar speed v=r/t")
    ax.set_title("Graph light-cone boundary proxy")
    ax.legend(fontsize=8)
    fig.tight_layout()
    if outfile:
        fig.savefig(outfile, dpi=180)
    return fig, ax
