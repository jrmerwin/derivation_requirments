"""
Coarse-grained SR worldline-clock audit for DEU triangular foam.

Purpose
-------
This add-on follows the interval-fingerprint and radar-coordinate audits.  It
tries two operational SR kinematics tests that are less singular than the
single-event gamma=t/tau estimator:

1. Light-cone boundary audit.
   In graph radar coordinates from an observer chain, events should occupy a
   diamond support r <= r_max(t)=min(t,T-t).  The high-quantile radial edge should
   scale with r_max, and near-null/low-subinterval-volume events should have
   higher radar speed than bulk events.

2. Coarse-grained time-dilation tube audit.
   For target speeds v, select events in a radar tube |r/t-v| < width over an
   early-time slab.  The longest chain contained in that tube is a moving-clock
   proxy.  Its tick count is compared with the rest observer's clock ticks over
   the same radar-time span:
       tau_v / tau_rest  ~ sqrt(1-v^2),
       gamma_v = tau_rest/tau_v ~ 1/sqrt(1-v^2).

Important caveats
-----------------
This is not a proof of Lorentz invariance.  The radial tube has no angular
orientation variable, so it is a coarse proxy for a boosted worldline rather than
a literal material clock.  Therefore controls are mandatory: if the same tube
estimator does not pass on finite 2+1D Minkowski controls, it should not be used
against the foam.

Expected notebook order
-----------------------
    %run -i src/deu_exp456_minimal.py
    %run -i src/deu_exp456_overflow_patch.py
    %run -i src/deu_sr_fingerprint.py
    # Build or load foam_result_512 from the SR fingerprint notebook.
    %run -i deu_sr_lorentz_radar_patch.py
    %run -i deu_sr_worldline_clock_patch.py

Typical use
-----------
    worldline_512 = run_worldline_clock_audit_from_foam_result(
        foam_result_512,
        foam_label="foam_cap512_SR_window",
        max_foam_intervals=80,
        control_reps=8,
        n_control_sizes=8,
        run_label="cap512_worldline",
        out_dir=OUT,
    )
    display(worldline_512["lightcone_summary"])
    display(worldline_512["time_dilation_summary"])
    display(worldline_512["time_dilation_bins"])
    print(worldline_512["verdict"])
"""

from __future__ import annotations

import math
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


def _wl_fit_line(x, y, min_points: int = 3) -> Dict[str, float]:
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    m = np.isfinite(x) & np.isfinite(y)
    x = x[m]
    y = y[m]
    if len(x) < int(min_points):
        return {"slope": np.nan, "intercept": np.nan, "r2": np.nan, "corr": np.nan, "n_fit": int(len(x))}
    slope, intercept = np.polyfit(x, y, 1)
    pred = intercept + slope * x
    ss_res = float(np.sum((y - pred) ** 2))
    ss_tot = float(np.sum((y - y.mean()) ** 2))
    r2 = np.nan if ss_tot <= 0 else 1.0 - ss_res / ss_tot
    corr = float(np.corrcoef(x, y)[0, 1]) if len(x) >= 3 and np.std(x) > 0 and np.std(y) > 0 else np.nan
    return {"slope": float(slope), "intercept": float(intercept), "r2": float(r2), "corr": corr, "n_fit": int(len(x))}


def _wl_bits_from_indices(indices: Iterable[int]) -> int:
    bits = 0
    for i in indices:
        bits |= bit_at(int(i))
    return int(bits)


def _wl_subset_height_edges(causet, indices: Sequence[int]) -> Tuple[int, int]:
    """Return (inclusive_height, edge_height) for the longest chain in a subset."""
    if indices is None or len(indices) == 0:
        return 0, 0
    bits = _wl_bits_from_indices(indices)
    if bits == 0:
        return 0, 0
    try:
        _, _, h = longest_chain_layers_bits(causet, bits)
    except Exception:
        return 0, 0
    h = int(h)
    return h, max(0, h - 1)


def _wl_add_basic_radar_columns(ev: pd.DataFrame) -> pd.DataFrame:
    """Add T_edges, t_frac, r_max, r_norm, and v columns if missing."""
    df = ev.copy()
    if len(df) == 0:
        return df
    if "T_edges" not in df.columns:
        df["T_edges"] = df["observer_height"].astype(float) - 1.0
    if "t_frac" not in df.columns:
        df["t_frac"] = df["t_radar"] / df["T_edges"].replace(0, np.nan)
    if "r_max" not in df.columns:
        df["r_max"] = np.minimum(df["t_radar"], df["T_edges"] - df["t_radar"])
    if "r_norm" not in df.columns:
        df["r_norm"] = df["r_radar"] / df["r_max"].replace(0, np.nan)
    if "v_radar" not in df.columns and {"r_radar", "t_radar"}.issubset(df.columns):
        df["v_radar"] = df["r_radar"] / df["t_radar"].replace(0, np.nan)
    return df


def _wl_selected_diamonds_from_foam_result(
    foam_result: Dict,
    selected_gap_bins: Optional[Sequence[int]] = None,
    max_intervals: int = 80,
) -> pd.DataFrame:
    diamonds = foam_result["diamonds"].copy()
    if selected_gap_bins is None:
        selected_gap_bins = foam_result.get("selected_gap_bins", None)
    if selected_gap_bins is not None and "gap_bin" in diamonds.columns:
        diamonds = diamonds[diamonds["gap_bin"].isin(list(selected_gap_bins))].copy()
    if len(diamonds) == 0:
        raise ValueError("No diamonds after selected_gap_bins filter.")
    if "V" not in diamonds.columns:
        if "V_strict_prescan" in diamonds.columns:
            diamonds["V"] = diamonds["V_strict_prescan"]
        else:
            diamonds["V"] = diamonds["interval_bits"].map(lambda x: int(x).bit_count())
    diamonds = diamonds.sort_values("V", ascending=False).head(int(max_intervals)).reset_index(drop=True)
    return diamonds


def radar_events_for_diamond_rows(
    causet,
    diamond_rows: pd.DataFrame,
    model: str,
    max_intervals: Optional[int] = None,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Compute radar-coordinate events for a set of diamond rows."""
    if diamond_rows is None or len(diamond_rows) == 0:
        return pd.DataFrame(), pd.DataFrame()
    df = diamond_rows.copy()
    if max_intervals is not None:
        df = df.head(int(max_intervals)).copy()
    event_parts = []
    meta_rows = []
    for k, row in enumerate(df.itertuples(index=False)):
        strict_bits = int(getattr(row, "interval_bits"))
        a = int(getattr(row, "a_index"))
        b = int(getattr(row, "b_index"))
        rid = f"{model}_d{k}"
        ev, meta = radar_coordinates_for_interval(causet, strict_bits, a, b, interval_id=rid, model=model)
        meta = dict(meta)
        meta["diamond_local_id"] = int(k)
        for col in ["gap_bin", "gap_lo", "gap_hi", "epoch_gap", "ep_a", "ep_b", "V"]:
            if hasattr(row, col):
                meta[col] = getattr(row, col)
                if len(ev):
                    ev[col] = getattr(row, col)
        if len(ev):
            ev["diamond_local_id"] = int(k)
            ev = _wl_add_basic_radar_columns(ev)
            event_parts.append(ev)
        meta_rows.append(meta)
    events = pd.concat(event_parts, ignore_index=True) if event_parts else pd.DataFrame()
    return events, pd.DataFrame(meta_rows)


def summarize_lightcone_boundary(
    radar_events: pd.DataFrame,
    n_t_bins: int = 8,
    min_per_bin: int = 50,
) -> pd.DataFrame:
    """
    Summarize graph light-cone boundary support.

    A good diamond-coordinate light cone has high-quantile r/r_max close to 1
    and near-null/low-subV events with larger v than bulk events.
    """
    if radar_events is None or len(radar_events) == 0:
        return pd.DataFrame()
    df = _wl_add_basic_radar_columns(radar_events)
    rows = []
    for model, sub0 in df.groupby("model", dropna=False):
        sub = sub0.copy()
        sub = sub[
            (~sub.get("is_top", False).astype(bool))
            & np.isfinite(sub["t_frac"])
            & np.isfinite(sub["r_norm"])
            & np.isfinite(sub["v_radar"])
            & (sub["r_max"] > 0)
            & (sub["t_frac"] >= 0.08)
            & (sub["t_frac"] <= 0.92)
            & (sub["r_norm"] >= 0)
            & (sub["r_norm"] <= 1.50)
        ].copy()
        if len(sub) == 0:
            rows.append({"model": model, "status": "empty"})
            continue

        # Time-slab edge support.
        edge_rows = []
        try:
            sub["t_bin"] = pd.qcut(sub["t_frac"].rank(method="first"), q=int(n_t_bins), labels=False, duplicates="drop")
        except Exception:
            sub["t_bin"] = np.floor(sub["t_frac"] * int(n_t_bins)).astype(int)
        for b, ss in sub.groupby("t_bin"):
            if len(ss) < int(min_per_bin):
                continue
            edge_rows.append({
                "t_bin": int(b),
                "n": int(len(ss)),
                "t_frac_med": float(ss["t_frac"].median()),
                "r_max_med": float(ss["r_max"].median()),
                "r_edge_q90": float(ss["r_radar"].quantile(0.90)),
                "r_edge_q95": float(ss["r_radar"].quantile(0.95)),
                "r_norm_q90": float(ss["r_norm"].quantile(0.90)),
                "r_norm_q95": float(ss["r_norm"].quantile(0.95)),
            })
        edge = pd.DataFrame(edge_rows)
        if len(edge) >= 3:
            fit90 = _wl_fit_line(edge["r_max_med"], edge["r_edge_q90"], min_points=3)
            fit95 = _wl_fit_line(edge["r_max_med"], edge["r_edge_q95"], min_points=3)
            edge_norm_q90_med = float(edge["r_norm_q90"].median())
            edge_norm_q95_med = float(edge["r_norm_q95"].median())
        else:
            fit90 = fit95 = {"slope": np.nan, "intercept": np.nan, "r2": np.nan, "corr": np.nan, "n_fit": int(len(edge))}
            edge_norm_q90_med = edge_norm_q95_med = np.nan

        # Near-null proxy. Low subinterval volume from the bottom should imply larger radar speed.
        lc = sub[np.isfinite(sub.get("subV_from_bottom", np.nan))].copy()
        if len(lc) >= 100 and lc["subV_from_bottom"].nunique() > 3:
            q15 = float(lc["subV_from_bottom"].quantile(0.15))
            q50 = float(lc["subV_from_bottom"].quantile(0.50))
            near = lc[lc["subV_from_bottom"] <= q15]
            bulk = lc[lc["subV_from_bottom"] >= q50]
            near_v = float(near["v_radar"].median()) if len(near) else np.nan
            bulk_v = float(bulk["v_radar"].median()) if len(bulk) else np.nan
            near_rnorm = float(near["r_norm"].median()) if len(near) else np.nan
            bulk_rnorm = float(bulk["r_norm"].median()) if len(bulk) else np.nan
            margin_v = near_v - bulk_v if np.isfinite(near_v) and np.isfinite(bulk_v) else np.nan
            margin_rnorm = near_rnorm - bulk_rnorm if np.isfinite(near_rnorm) and np.isfinite(bulk_rnorm) else np.nan
            near_frac_v_gt_08 = float((near["v_radar"] > 0.80).mean()) if len(near) else np.nan
        else:
            q15 = q50 = near_v = bulk_v = near_rnorm = bulk_rnorm = margin_v = margin_rnorm = near_frac_v_gt_08 = np.nan
            near = bulk = pd.DataFrame()

        rows.append({
            "model": str(model),
            "status": "ok",
            "n_events": int(len(sub)),
            "n_intervals": int(sub["interval_id"].nunique()) if "interval_id" in sub else np.nan,
            "edge_n_bins": int(len(edge)),
            "edge_rnorm_q90_median": edge_norm_q90_med,
            "edge_rnorm_q95_median": edge_norm_q95_med,
            "edge_q90_slope_vs_rmax": fit90["slope"],
            "edge_q90_r2": fit90["r2"],
            "edge_q95_slope_vs_rmax": fit95["slope"],
            "edge_q95_r2": fit95["r2"],
            "near_subV_q15": q15,
            "bulk_subV_q50": q50,
            "near_v_median": near_v,
            "bulk_v_median": bulk_v,
            "near_minus_bulk_v": margin_v,
            "near_rnorm_median": near_rnorm,
            "bulk_rnorm_median": bulk_rnorm,
            "near_minus_bulk_rnorm": margin_rnorm,
            "near_frac_v_gt_0p8": near_frac_v_gt_08,
            "n_near": int(len(near)),
            "n_bulk": int(len(bulk)),
        })
    out = pd.DataFrame(rows)
    return out


def time_dilation_tube_rows_for_diamonds(
    causet,
    radar_events: pd.DataFrame,
    model: str,
    v_targets: Sequence[float] = (0.0, 0.2, 0.4, 0.6, 0.75),
    v_band: float = 0.075,
    t_frac_lo: float = 0.15,
    t_frac_hi_base: float = 0.55,
    min_tube_events: int = 8,
) -> pd.DataFrame:
    """
    Build coarse-grained moving-clock proxies by velocity tubes.

    For each interval and target v, we select events with r/t near v in an
    early-time slab.  The longest chain through that subset is tau_v.  The rest
    clock tau_rest is the number of observer-chain ticks over the same t-slab.
    """
    if radar_events is None or len(radar_events) == 0:
        return pd.DataFrame()
    df = _wl_add_basic_radar_columns(radar_events)
    rows = []
    for interval_id, sub0 in df.groupby("interval_id", dropna=False):
        sub = sub0.copy()
        if len(sub) == 0:
            continue
        Tvals = sub["T_edges"].dropna().astype(float).unique()
        if len(Tvals) == 0:
            continue
        T = float(np.nanmedian(Tvals))
        if not np.isfinite(T) or T < 6:
            continue
        # Use events that are not the top endpoint and have valid radar speed.
        base = sub[
            (~sub.get("is_top", False).astype(bool))
            & np.isfinite(sub["t_radar"])
            & np.isfinite(sub["v_radar"])
            & (sub["t_radar"] > 0)
            & (sub["v_radar"] >= 0)
            & (sub["v_radar"] < 0.995)
        ].copy()
        if len(base) == 0:
            continue
        for v0 in v_targets:
            v0 = float(v0)
            # Keep the tube in the lower half of the Alexandrov interval so that r=v*t
            # is not truncated by the top light cone.  For v0, the line exists while
            # t <= T/(1+v0).  Use a safety factor.
            t_hi = min(float(t_frac_hi_base) * T, 0.90 * T / (1.0 + max(0.0, v0)))
            t_lo = float(t_frac_lo) * T
            if t_hi <= t_lo + 2.0:
                continue
            rest_edges = max(0.0, math.floor(t_hi) - math.ceil(t_lo))
            if rest_edges <= 2:
                continue
            band = max(float(v_band), 0.12 if v0 <= 0.05 else float(v_band))
            tube = base[
                (base["t_radar"] >= t_lo)
                & (base["t_radar"] <= t_hi)
                & (np.abs(base["v_radar"] - v0) <= band)
            ].copy()
            if len(tube) < int(min_tube_events):
                rows.append({
                    "model": model,
                    "interval_id": interval_id,
                    "v_target": v0,
                    "status": "too_few_events",
                    "T_edges": T,
                    "t_lo": t_lo,
                    "t_hi": t_hi,
                    "delta_t": t_hi - t_lo,
                    "rest_edges": rest_edges,
                    "tube_n_events": int(len(tube)),
                })
                continue
            h_incl, h_edges = _wl_subset_height_edges(causet, tube["event_index"].astype(int).tolist())
            tau_ratio = h_edges / rest_edges if rest_edges > 0 else np.nan
            gamma_cg = rest_edges / h_edges if h_edges > 0 else np.nan
            tau_target = math.sqrt(max(0.0, 1.0 - v0 * v0))
            gamma_target = 1.0 / tau_target if tau_target > 0 else np.nan
            v_actual_med = float(tube["v_radar"].median())
            tau_target_actual = math.sqrt(max(0.0, 1.0 - v_actual_med * v_actual_med)) if np.isfinite(v_actual_med) else np.nan
            gamma_target_actual = 1.0 / tau_target_actual if np.isfinite(tau_target_actual) and tau_target_actual > 0 else np.nan
            rows.append({
                "model": model,
                "interval_id": interval_id,
                "v_target": v0,
                "status": "ok" if h_edges > 0 else "no_chain",
                "T_edges": T,
                "t_lo": t_lo,
                "t_hi": t_hi,
                "delta_t": t_hi - t_lo,
                "rest_edges": float(rest_edges),
                "tube_n_events": int(len(tube)),
                "tube_h_inclusive": int(h_incl),
                "tube_h_edges": float(h_edges),
                "tau_ratio_measured": float(tau_ratio) if np.isfinite(tau_ratio) else np.nan,
                "gamma_cg_measured": float(gamma_cg) if np.isfinite(gamma_cg) else np.nan,
                "v_actual_median": v_actual_med,
                "v_actual_q25": float(tube["v_radar"].quantile(0.25)),
                "v_actual_q75": float(tube["v_radar"].quantile(0.75)),
                "tau_ratio_target": float(tau_target),
                "gamma_target": float(gamma_target) if np.isfinite(gamma_target) else np.nan,
                "tau_ratio_target_actual_v": float(tau_target_actual) if np.isfinite(tau_target_actual) else np.nan,
                "gamma_target_actual_v": float(gamma_target_actual) if np.isfinite(gamma_target_actual) else np.nan,
                "tau_ratio_rel_err": abs(tau_ratio - tau_target) / max(1e-9, tau_target) if np.isfinite(tau_ratio) else np.nan,
                "gamma_rel_err": abs(gamma_cg - gamma_target) / max(1e-9, gamma_target) if np.isfinite(gamma_cg) and np.isfinite(gamma_target) else np.nan,
            })
    return pd.DataFrame(rows)


def summarize_time_dilation_tubes(tube_df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Return model summary and model-by-velocity bin table for tube clocks."""
    if tube_df is None or len(tube_df) == 0:
        return pd.DataFrame(), pd.DataFrame()
    ok = tube_df[tube_df["status"] == "ok"].copy()
    if len(ok) == 0:
        return pd.DataFrame(), pd.DataFrame()
    bin_rows = []
    for (model, v0), sub in ok.groupby(["model", "v_target"], dropna=False):
        if len(sub) == 0:
            continue
        bin_rows.append({
            "model": str(model),
            "v_target": float(v0),
            "n_tubes": int(len(sub)),
            "tube_events_med": float(np.nanmedian(sub["tube_n_events"])),
            "rest_edges_med": float(np.nanmedian(sub["rest_edges"])),
            "tube_h_edges_med": float(np.nanmedian(sub["tube_h_edges"])),
            "v_actual_median": float(np.nanmedian(sub["v_actual_median"])),
            "tau_ratio_median": float(np.nanmedian(sub["tau_ratio_measured"])),
            "tau_ratio_q25": float(np.nanquantile(sub["tau_ratio_measured"], 0.25)),
            "tau_ratio_q75": float(np.nanquantile(sub["tau_ratio_measured"], 0.75)),
            "tau_ratio_target": float(np.nanmedian(sub["tau_ratio_target"])),
            "gamma_cg_median": float(np.nanmedian(sub["gamma_cg_measured"])),
            "gamma_target": float(np.nanmedian(sub["gamma_target"])),
            "tau_ratio_rel_err_median": float(np.nanmedian(sub["tau_ratio_rel_err"])),
            "gamma_rel_err_median": float(np.nanmedian(sub["gamma_rel_err"])),
        })
    bins = pd.DataFrame(bin_rows)
    summary_rows = []
    for model, sub in ok.groupby("model", dropna=False):
        b = bins[bins["model"] == str(model)].copy()
        # Use v>0 bins for regression; v=0 target is calibration.
        bf = b[(b["v_target"] > 0.05) & np.isfinite(b["gamma_cg_median"]) & np.isfinite(b["gamma_target"])].copy()
        gf = _wl_fit_line(bf["gamma_target"], bf["gamma_cg_median"], min_points=3)
        tf = _wl_fit_line(bf["tau_ratio_target"], bf["tau_ratio_median"], min_points=3)
        if len(bf) >= 2:
            # Gamma should increase with v; tau ratio should decrease with v.
            gg = bf.sort_values("v_target")["gamma_cg_median"].to_numpy(dtype=float)
            tt = bf.sort_values("v_target")["tau_ratio_median"].to_numpy(dtype=float)
            gamma_mon = float(np.mean(np.diff(gg) >= -1e-9)) if len(gg) > 1 else np.nan
            tau_mon = float(np.mean(np.diff(tt) <= 1e-9)) if len(tt) > 1 else np.nan
        else:
            gamma_mon = tau_mon = np.nan
        summary_rows.append({
            "model": str(model),
            "n_ok_tubes": int(len(sub)),
            "n_velocity_bins": int(len(b)),
            "n_fit_velocity_bins": int(len(bf)),
            "rest_edges_med": float(np.nanmedian(sub["rest_edges"])),
            "tube_h_edges_med": float(np.nanmedian(sub["tube_h_edges"])),
            "gamma_cg_rel_err_median": float(np.nanmedian(sub["gamma_rel_err"])),
            "tau_ratio_rel_err_median": float(np.nanmedian(sub["tau_ratio_rel_err"])),
            "gamma_fit_slope": gf["slope"],
            "gamma_fit_intercept": gf["intercept"],
            "gamma_fit_r2": gf["r2"],
            "gamma_fit_corr": gf["corr"],
            "tau_ratio_fit_slope": tf["slope"],
            "tau_ratio_fit_intercept": tf["intercept"],
            "tau_ratio_fit_r2": tf["r2"],
            "tau_ratio_fit_corr": tf["corr"],
            "gamma_monotone_fraction": gamma_mon,
            "tau_ratio_monotone_fraction": tau_mon,
        })
    summary = pd.DataFrame(summary_rows)
    return summary, bins.sort_values(["model", "v_target"]).reset_index(drop=True) if len(bins) else bins


def build_worldline_control_samples(
    sizes: Sequence[int],
    reps_per_size: int = 4,
    seed: int = 12345,
    v_targets: Sequence[float] = (0.0, 0.2, 0.4, 0.6, 0.75),
    v_band: float = 0.075,
    max_models: Sequence[str] = ("minkowski_2p1D", "minkowski_3p1D", "random_DAG", "chain_1D"),
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Build radar events, metadata, and tube rows for finite controls."""
    event_parts = []
    meta_parts = []
    tube_parts = []
    for n in sizes:
        n = int(max(12, n))
        if "chain_1D" in max_models:
            c, a, b = make_chain_interval_causet(n)
            ddf = pd.DataFrame([{"a_index": a, "b_index": b, "interval_bits": int(c.descendant_bits[a] & c.ancestor_bits[b]), "V": n}])
            ev, meta = radar_events_for_diamond_rows(c, ddf, "chain_1D")
            tubes = time_dilation_tube_rows_for_diamonds(c, ev, "chain_1D", v_targets=v_targets, v_band=v_band)
            if len(ev): event_parts.append(ev)
            if len(meta): meta_parts.append(meta)
            if len(tubes): tube_parts.append(tubes)
        for rep in range(int(reps_per_size)):
            base = int(seed + 100000 * rep + 97 * n)
            if "minkowski_2p1D" in max_models:
                c, a, b = make_minkowski_interval_causet(n, d=3, seed=base + 3)
                ddf = pd.DataFrame([{"a_index": a, "b_index": b, "interval_bits": int(c.descendant_bits[a] & c.ancestor_bits[b]), "V": n}])
                ev, meta = radar_events_for_diamond_rows(c, ddf, "minkowski_2p1D")
                tubes = time_dilation_tube_rows_for_diamonds(c, ev, "minkowski_2p1D", v_targets=v_targets, v_band=v_band)
                if len(ev): event_parts.append(ev)
                if len(meta): meta_parts.append(meta)
                if len(tubes): tube_parts.append(tubes)
            if "minkowski_3p1D" in max_models:
                c, a, b = make_minkowski_interval_causet(n, d=4, seed=base + 4)
                ddf = pd.DataFrame([{"a_index": a, "b_index": b, "interval_bits": int(c.descendant_bits[a] & c.ancestor_bits[b]), "V": n}])
                ev, meta = radar_events_for_diamond_rows(c, ddf, "minkowski_3p1D")
                tubes = time_dilation_tube_rows_for_diamonds(c, ev, "minkowski_3p1D", v_targets=v_targets, v_band=v_band)
                if len(ev): event_parts.append(ev)
                if len(meta): meta_parts.append(meta)
                if len(tubes): tube_parts.append(tubes)
            if "random_DAG" in max_models:
                c, a, b = make_random_dag_interval_causet(n, p=0.025, seed=base + 999)
                ddf = pd.DataFrame([{"a_index": a, "b_index": b, "interval_bits": int(c.descendant_bits[a] & c.ancestor_bits[b]), "V": n}])
                ev, meta = radar_events_for_diamond_rows(c, ddf, "random_DAG")
                tubes = time_dilation_tube_rows_for_diamonds(c, ev, "random_DAG", v_targets=v_targets, v_band=v_band)
                if len(ev): event_parts.append(ev)
                if len(meta): meta_parts.append(meta)
                if len(tubes): tube_parts.append(tubes)
    events = pd.concat(event_parts, ignore_index=True) if event_parts else pd.DataFrame()
    meta = pd.concat(meta_parts, ignore_index=True) if meta_parts else pd.DataFrame()
    tubes = pd.concat(tube_parts, ignore_index=True) if tube_parts else pd.DataFrame()
    return events, meta, tubes


def _worldline_verdict(light_summary: pd.DataFrame, tube_summary: pd.DataFrame, foam_label: str) -> str:
    pieces = []
    if light_summary is None or len(light_summary) == 0 or foam_label not in set(light_summary.get("model", [])):
        return "UNDETERMINED: no foam light-cone summary."
    lc = light_summary[light_summary["model"] == foam_label].iloc[0]
    lc_ok = bool(
        lc.get("edge_n_bins", 0) >= 4
        and lc.get("edge_rnorm_q90_median", 0) >= 0.70
        and lc.get("near_minus_bulk_v", -np.inf) > 0.10
    )
    if lc_ok:
        pieces.append("light-cone boundary/support passes")
    else:
        pieces.append("light-cone boundary/support is weak")

    if tube_summary is None or len(tube_summary) == 0 or foam_label not in set(tube_summary.get("model", [])):
        pieces.append("no usable tube-clock result")
        return "PARTIAL / LIGHT-CONE ONLY: " + "; ".join(pieces)
    foam = tube_summary[tube_summary["model"] == foam_label].iloc[0]
    # First require the estimator to work at least moderately on finite 2+1D controls.
    if "minkowski_2p1D" in set(tube_summary["model"]):
        m2 = tube_summary[tube_summary["model"] == "minkowski_2p1D"].iloc[0]
        estimator_calibrated = bool(
            m2.get("n_fit_velocity_bins", 0) >= 3
            and m2.get("gamma_fit_corr", -np.inf) > 0.45
            and m2.get("gamma_monotone_fraction", 0) >= 0.60
        )
    else:
        estimator_calibrated = False
    foam_td_ok = bool(
        foam.get("n_fit_velocity_bins", 0) >= 3
        and foam.get("gamma_fit_corr", -np.inf) > 0.35
        and foam.get("gamma_monotone_fraction", 0) >= 0.60
    )
    if estimator_calibrated:
        pieces.append("tube-clock estimator calibrates on 2+1D Minkowski controls")
    else:
        pieces.append("tube-clock estimator does not calibrate cleanly on 2+1D controls")
    if foam_td_ok:
        pieces.append("foam coarse-grained time dilation is monotone/positive")
    else:
        pieces.append("foam coarse-grained time dilation is not yet recovered")
    if lc_ok and estimator_calibrated and foam_td_ok:
        return "PASS / PROMISING: light-cone boundary and coarse-grained tube-clock time dilation pass finite-control screening. " + "; ".join(pieces)
    if lc_ok and (not estimator_calibrated):
        return "PARTIAL PASS: light-cone boundary passes, but the tube-clock estimator is not reliable enough even on controls. " + "; ".join(pieces)
    if lc_ok:
        return "PARTIAL PASS: light-cone boundary passes, but foam tube-clock time dilation does not yet pass. " + "; ".join(pieces)
    return "NOT YET PASSING: operational light-cone/time-dilation tests are weak. " + "; ".join(pieces)


def run_worldline_clock_audit_from_foam_result(
    foam_result: Dict,
    foam_label: str = "foam_cap512_SR_window",
    selected_gap_bins: Optional[Sequence[int]] = None,
    max_foam_intervals: int = 80,
    control_reps: int = 8,
    n_control_sizes: int = 8,
    v_targets: Sequence[float] = (0.0, 0.2, 0.4, 0.6, 0.75),
    v_band: float = 0.075,
    seed: int = 9090,
    run_label: str = "worldline",
    out_dir: Optional[Path | str] = None,
) -> Dict[str, object]:
    """End-to-end light-cone + coarse-grained time-dilation audit."""
    rg2 = foam_result["rg2"]
    diamonds = _wl_selected_diamonds_from_foam_result(foam_result, selected_gap_bins=selected_gap_bins, max_intervals=max_foam_intervals)
    foam_events, foam_meta = radar_events_for_diamond_rows(rg2, diamonds, foam_label, max_intervals=max_foam_intervals)
    foam_tubes = time_dilation_tube_rows_for_diamonds(rg2, foam_events, foam_label, v_targets=v_targets, v_band=v_band)

    # Match control interval sizes to the selected foam diamonds.
    Vvals = diamonds["V"].astype(float).to_numpy()
    qs = np.linspace(0.10, 0.90, int(n_control_sizes))
    sizes = sorted(set(int(max(20, round(np.nanquantile(Vvals, q)))) for q in qs))
    control_events, control_meta, control_tubes = build_worldline_control_samples(
        sizes=sizes,
        reps_per_size=control_reps,
        seed=seed + 1000,
        v_targets=v_targets,
        v_band=v_band,
    )

    all_events = pd.concat([foam_events, control_events], ignore_index=True) if len(control_events) else foam_events.copy()
    all_tubes = pd.concat([foam_tubes, control_tubes], ignore_index=True) if len(control_tubes) else foam_tubes.copy()
    light_summary = summarize_lightcone_boundary(all_events)
    tube_summary, tube_bins = summarize_time_dilation_tubes(all_tubes)
    verdict = _worldline_verdict(light_summary, tube_summary, foam_label)

    result = {
        "foam_events": foam_events,
        "control_events": control_events,
        "events": all_events,
        "foam_meta": foam_meta,
        "control_meta": control_meta,
        "foam_tubes": foam_tubes,
        "control_tubes": control_tubes,
        "tubes": all_tubes,
        "lightcone_summary": light_summary,
        "time_dilation_summary": tube_summary,
        "time_dilation_bins": tube_bins,
        "control_sizes": sizes,
        "selected_gap_bins": tuple(selected_gap_bins) if selected_gap_bins is not None else tuple(foam_result.get("selected_gap_bins", ())),
        "verdict": verdict,
    }

    if out_dir is not None:
        out = Path(out_dir)
        out.mkdir(parents=True, exist_ok=True)
        all_events.to_csv(out / f"worldline_radar_events_{run_label}.csv", index=False)
        all_tubes.to_csv(out / f"worldline_tube_rows_{run_label}.csv", index=False)
        light_summary.to_csv(out / f"worldline_lightcone_summary_{run_label}.csv", index=False)
        tube_summary.to_csv(out / f"worldline_time_dilation_summary_{run_label}.csv", index=False)
        tube_bins.to_csv(out / f"worldline_time_dilation_bins_{run_label}.csv", index=False)
        (out / f"worldline_verdict_{run_label}.txt").write_text(verdict, encoding="utf-8")
        report = []
        report.append(f"# Coarse-grained SR worldline-clock audit: {run_label}\n")
        report.append("## Verdict\n")
        report.append(verdict + "\n")
        report.append("\n## Light-cone boundary summary\n")
        report.append(light_summary.to_markdown(index=False) if len(light_summary) else "No light-cone summary.")
        report.append("\n\n## Time-dilation tube summary\n")
        report.append(tube_summary.to_markdown(index=False) if len(tube_summary) else "No time-dilation summary.")
        report.append("\n\n## Time-dilation bins\n")
        report.append(tube_bins.to_markdown(index=False) if len(tube_bins) else "No time-dilation bins.")
        (out / f"worldline_report_{run_label}.md").write_text("\n".join(report), encoding="utf-8")
    return result


def plot_lightcone_edge_summary(light_summary: pd.DataFrame, outfile: Optional[str] = None):
    import matplotlib.pyplot as plt
    df = light_summary.copy()
    fig, ax = plt.subplots(figsize=(7, 4.5))
    x = np.arange(len(df))
    ax.bar(x - 0.18, df["edge_rnorm_q90_median"], width=0.36, label="q90 r/rmax")
    ax.bar(x + 0.18, df["near_minus_bulk_v"], width=0.36, label="near-bulk v margin")
    ax.axhline(1.0, linestyle="--", linewidth=1, label="edge target")
    ax.set_xticks(x)
    ax.set_xticklabels(df["model"], rotation=30, ha="right")
    ax.set_title("Light-cone boundary diagnostics")
    ax.legend(fontsize=8)
    fig.tight_layout()
    if outfile:
        Path(outfile).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(outfile, dpi=180)
    return fig, ax


def plot_time_dilation_bins(tube_bins: pd.DataFrame, outfile: Optional[str] = None, models: Optional[Sequence[str]] = None):
    import matplotlib.pyplot as plt
    df = tube_bins.copy()
    if models is not None:
        df = df[df["model"].isin(list(models))].copy()
    fig, ax = plt.subplots(figsize=(7, 5))
    for model, sub in df.groupby("model"):
        sub = sub.sort_values("v_target")
        ax.plot(sub["v_target"], sub["gamma_cg_median"], marker="o", label=str(model))
    v = np.linspace(0, 0.85, 200)
    ax.plot(v, 1.0 / np.sqrt(1.0 - v*v), linestyle="--", label="SR gamma(v)")
    ax.set_xlabel("target radar speed v")
    ax.set_ylabel("coarse gamma = rest ticks / tube-chain ticks")
    ax.set_title("Coarse-grained tube-clock gamma")
    ax.legend(fontsize=8)
    ax.grid(True, alpha=0.25)
    fig.tight_layout()
    if outfile:
        Path(outfile).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(outfile, dpi=180)
    return fig, ax

