"""
SR fingerprint audit v2: matched-control and bootstrap profile-distance patch.

Run after the original SR notebook has loaded src/deu_sr_fingerprint.py and after the
paper-mode foam result has been computed.

Expected in the notebook namespace, when available:
    foam_result
    foam_window_label
    OUT
    RUN_MODE

This patch does not rerun the foam unless you ask it to. It rebuilds larger, volume-matched
Minkowski/chain/random controls from the selected foam-window interval-size distribution and
adds bootstrap uncertainty to the layer-profile distances.
"""

from __future__ import annotations

import math
from pathlib import Path
from typing import Dict, Iterable, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


def _sr_patch_require(name: str):
    if name not in globals():
        raise RuntimeError(
            f"Required function/variable {name!r} is missing. "
            "Run the original SR notebook/source first, then `%run -i deu_sr_fingerprint_v2_controls_patch.py`."
        )
    return globals()[name]


def _quantile_sizes(values, n_sizes: int = 12, min_size: int = 20, max_size: Optional[int] = None):
    vals = np.asarray(values, dtype=float)
    vals = vals[np.isfinite(vals) & (vals > 0)]
    if len(vals) == 0:
        raise ValueError("No positive sizes available")
    qs = np.linspace(0.05, 0.95, int(n_sizes))
    sizes = np.unique(np.round(np.quantile(vals, qs)).astype(int))
    sizes = sizes[sizes >= int(min_size)]
    if max_size is not None:
        sizes = sizes[sizes <= int(max_size)]
    return [int(x) for x in sizes]


def build_matched_control_fingerprints_from_foam(
    foam_interval_df: pd.DataFrame,
    n_sizes: int = 12,
    reps_per_size: int = 12,
    seed: int = 2027,
    n_profile_bins: int = 21,
    random_dag_p: float = 0.025,
    include_random: bool = True,
    include_chain: bool = True,
    min_size: int = 20,
    max_size: Optional[int] = None,
) -> Tuple[pd.DataFrame, pd.DataFrame, Sequence[int]]:
    """
    Build larger controls whose fixed endpoint interval sizes match the selected foam-window
    V_strict distribution by quantiles.

    This fixes the main weakness of the initial SR audit: tiny external controls with only
    a few fixed sizes. It still does not prove Lorentz invariance; it is a tighter flat-
    interval fingerprint control.
    """
    if foam_interval_df is None or len(foam_interval_df) == 0:
        raise ValueError("foam_interval_df is empty")
    sizes = _quantile_sizes(foam_interval_df["V_strict"], n_sizes=n_sizes, min_size=min_size, max_size=max_size)
    if len(sizes) == 0:
        raise ValueError("No usable control sizes after filtering")

    rows = []
    profile_rows = []
    rng = np.random.default_rng(seed)

    for n in sizes:
        if include_chain:
            c, a, b = make_chain_interval_causet(int(n))
            row, prof = fingerprint_fixed_endpoint_causet(
                c, a, b, "chain_1D", f"chain_matched_n{n}", n_profile_bins,
                {"n_interior_target": int(n), "rep": 0, "matched_control": True},
            )
            rows.append(row); profile_rows.extend(prof)

        for rep in range(int(reps_per_size)):
            base_seed = int(seed + 1000003 * rep + 9176 * int(n) + int(rng.integers(0, 10_000_000)))
            for d, label in [(3, "minkowski_2p1D"), (4, "minkowski_3p1D")]:
                c, a, b = make_minkowski_interval_causet(int(n), d=d, seed=base_seed + 101 * d)
                row, prof = fingerprint_fixed_endpoint_causet(
                    c, a, b, label, f"{label}_matched_n{n}_rep{rep}", n_profile_bins,
                    {"n_interior_target": int(n), "rep": rep, "control_d": d, "matched_control": True},
                )
                rows.append(row); profile_rows.extend(prof)
            if include_random:
                c, a, b = make_random_dag_interval_causet(int(n), p=random_dag_p, seed=base_seed + 999)
                row, prof = fingerprint_fixed_endpoint_causet(
                    c, a, b, "random_DAG", f"random_matched_n{n}_rep{rep}", n_profile_bins,
                    {"n_interior_target": int(n), "rep": rep, "random_dag_p": random_dag_p, "matched_control": True},
                )
                rows.append(row); profile_rows.extend(prof)

    return pd.DataFrame(rows), pd.DataFrame(profile_rows), sizes


def _average_profiles_for_selected_ids(profile_df: pd.DataFrame, id_map: Dict[str, Sequence[str]]) -> pd.DataFrame:
    parts = []
    for model, ids in id_map.items():
        sub = profile_df[(profile_df["model"] == model) & (profile_df["interval_id"].isin(list(ids)))].copy()
        if len(sub) == 0:
            continue
        parts.append(sub)
    if not parts:
        return pd.DataFrame()
    return average_profiles(pd.concat(parts, ignore_index=True))


def bootstrap_profile_distance_to_foam(
    profile_df: pd.DataFrame,
    foam_model: str,
    candidate_models: Optional[Sequence[str]] = None,
    n_boot: int = 300,
    seed: int = 2028,
) -> pd.DataFrame:
    """
    Bootstrap JS/L1/L2 profile-distance uncertainty by resampling interval profiles within model.

    This answers whether `minkowski_2p1D` is clearly closer than `minkowski_3p1D`, rather than
    relying on a single point estimate.
    """
    if profile_df is None or len(profile_df) == 0:
        return pd.DataFrame()
    models = sorted(profile_df["model"].dropna().unique().tolist())
    if foam_model not in models:
        raise ValueError(f"foam_model {foam_model!r} not found in profile_df")
    if candidate_models is None:
        candidate_models = [m for m in models if m != foam_model]
    else:
        candidate_models = [m for m in candidate_models if m in models and m != foam_model]
    if not candidate_models:
        return pd.DataFrame()

    rng = np.random.default_rng(seed)
    ids_by_model = {
        m: profile_df.loc[profile_df["model"] == m, "interval_id"].drop_duplicates().to_numpy()
        for m in [foam_model] + list(candidate_models)
    }
    rows = []
    for b in range(int(n_boot)):
        sample_ids = {}
        for m, ids in ids_by_model.items():
            if len(ids) == 0:
                continue
            sample_ids[m] = rng.choice(ids, size=len(ids), replace=True)
        # Duplicated interval_ids would collapse under isin, so explicitly copy and relabel.
        boot_parts = []
        for m, sampled in sample_ids.items():
            model_prof = profile_df[profile_df["model"] == m]
            for k, iid in enumerate(sampled):
                part = model_prof[model_prof["interval_id"] == iid].copy()
                part["interval_id"] = f"boot{b}_{m}_{k}"
                boot_parts.append(part)
        boot_prof = pd.concat(boot_parts, ignore_index=True) if boot_parts else pd.DataFrame()
        avg = average_profiles(boot_prof)
        if len(avg) == 0:
            continue
        dist = profile_distance_table(avg, foam_model)
        for row in dist.itertuples(index=False):
            if getattr(row, "model") == foam_model:
                continue
            rows.append({
                "boot": b,
                "model": getattr(row, "model"),
                "l1_distance": float(getattr(row, "l1_distance")),
                "l2_distance": float(getattr(row, "l2_distance")),
                "js_distance": float(getattr(row, "js_distance")),
            })
    boot_df = pd.DataFrame(rows)
    if len(boot_df) == 0:
        return boot_df

    summ = (
        boot_df.groupby("model", as_index=False)
        .agg(
            js_median=("js_distance", "median"),
            js_lo=("js_distance", lambda x: float(np.quantile(x, 0.025))),
            js_hi=("js_distance", lambda x: float(np.quantile(x, 0.975))),
            l1_median=("l1_distance", "median"),
            l2_median=("l2_distance", "median"),
            n_boot=("js_distance", "size"),
        )
        .sort_values("js_median")
        .reset_index(drop=True)
    )
    # Probability each model is the nearest external candidate in bootstrap replicate.
    winners = boot_df.loc[boot_df.groupby("boot")["js_distance"].idxmin(), "model"].value_counts(normalize=True)
    summ["p_nearest_by_js"] = summ["model"].map(winners).fillna(0.0).astype(float)
    return summ


def run_sr_matched_control_stress_test(
    foam_window_intervals: Optional[pd.DataFrame] = None,
    foam_window_profiles: Optional[pd.DataFrame] = None,
    foam_model: Optional[str] = None,
    out_dir: Optional[str | Path] = None,
    run_label: str = "paper_v2",
    n_sizes: int = 12,
    reps_per_size: int = 12,
    n_boot: int = 300,
    seed: int = 2027,
) -> Dict[str, pd.DataFrame]:
    """
    End-to-end v2 stress test. Reuses the already-computed selected foam window and rebuilds
    stronger matched controls. Writes compact CSV/MD outputs.
    """
    # Resolve defaults from the notebook namespace.
    if foam_window_intervals is None:
        fr = globals().get("foam_result", None)
        if fr is None:
            raise RuntimeError("foam_result not found; pass foam_window_intervals/profiles explicitly")
        foam_window_intervals = fr.get("foam_window_intervals")
        foam_window_profiles = fr.get("foam_window_profiles") if foam_window_profiles is None else foam_window_profiles
    if foam_window_profiles is None:
        raise RuntimeError("foam_window_profiles is missing")
    if foam_model is None:
        foam_model = globals().get("foam_window_label", None)
        if foam_model is None and "model" in foam_window_intervals:
            foam_model = str(foam_window_intervals["model"].iloc[0])
    if foam_model is None:
        raise RuntimeError("foam_model / foam_window_label could not be resolved")
    if out_dir is None:
        out_dir = globals().get("OUT", Path("outputs"))
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    control_intervals, control_profiles, sizes = build_matched_control_fingerprints_from_foam(
        foam_window_intervals,
        n_sizes=n_sizes,
        reps_per_size=reps_per_size,
        seed=seed,
        n_profile_bins=int(foam_window_profiles["profile_bin"].max() + 1) if len(foam_window_profiles) else 21,
    )
    combined_intervals = pd.concat([foam_window_intervals, control_intervals], ignore_index=True)
    combined_profiles = pd.concat([foam_window_profiles, control_profiles], ignore_index=True)

    summary = summarize_interval_fingerprints(combined_intervals)
    avg = average_profiles(combined_profiles)
    dist = profile_distance_table(avg, foam_model)
    external_dist = dist[(dist["model"] != foam_model) & (~dist["model"].astype(str).str.startswith("foam_"))].copy()
    boot = bootstrap_profile_distance_to_foam(
        combined_profiles,
        foam_model=foam_model,
        candidate_models=["minkowski_2p1D", "minkowski_3p1D", "random_DAG", "chain_1D"],
        n_boot=n_boot,
        seed=seed + 1,
    )

    # Compact verdict.
    foam_row = summary[summary["model"] == foam_model].iloc[0].to_dict()
    nearest_external = external_dist.iloc[0]["model"] if len(external_dist) else None
    p_2p1 = float(boot.loc[boot["model"] == "minkowski_2p1D", "p_nearest_by_js"].iloc[0]) if len(boot[boot["model"] == "minkowski_2p1D"]) else np.nan
    p_3p1 = float(boot.loc[boot["model"] == "minkowski_3p1D", "p_nearest_by_js"].iloc[0]) if len(boot[boot["model"] == "minkowski_3p1D"]) else np.nan

    mm_ok = abs(float(foam_row["MM_med"]) - 3.0) <= 0.35
    vol_ok = abs(float(foam_row["volume_slope"]) - 3.0) <= 0.35 and float(foam_row["volume_r2"]) >= 0.95
    mid_or_max_ok = (
        (abs(float(foam_row["mid_layer_slope"]) - 2.0) <= 0.40 and float(foam_row["mid_layer_r2"]) >= 0.80)
        or (abs(float(foam_row["max_layer_slope"]) - 2.0) <= 0.40 and float(foam_row["max_layer_r2"]) >= 0.85)
    )
    profile_ok = nearest_external == "minkowski_2p1D" and (not np.isfinite(p_2p1) or p_2p1 >= max(0.5, p_3p1))

    if mm_ok and vol_ok and mid_or_max_ok and profile_ok:
        verdict = "PASS / PROMISING after matched-control stress test"
    elif mm_ok and vol_ok and mid_or_max_ok:
        verdict = "MIXED: scaling passes, profile-control separation remains inconclusive"
    else:
        verdict = "FAIL / NOT YET SR-LIKE under matched-control stress test"

    report_lines = []
    report_lines.append("# SR fingerprint v2 matched-control stress test\n")
    report_lines.append(f"Selected foam model: `{foam_model}`\n")
    report_lines.append(f"Matched control sizes: {list(map(int, sizes))}\n")
    report_lines.append(f"Verdict: **{verdict}**\n")
    report_lines.append("\n## Summary\n")
    report_lines.append(summary.to_markdown(index=False))
    report_lines.append("\n\n## External profile distances to selected foam window\n")
    report_lines.append(external_dist.to_markdown(index=False))
    report_lines.append("\n\n## Bootstrap JS profile-distance summary\n")
    report_lines.append(boot.to_markdown(index=False) if len(boot) else "No bootstrap result")
    report_lines.append("\n\nInterpretation note: this v2 test is stricter than the first paper run because controls are size-matched to the selected foam-window interval-volume distribution and profile-distance uncertainty is bootstrapped.\n")

    prefix = out_dir / f"sr_v2_matched_controls_{run_label}"
    control_intervals.to_csv(str(prefix) + "_control_intervals.csv", index=False)
    control_profiles.to_csv(str(prefix) + "_control_profiles.csv", index=False)
    combined_intervals.to_csv(str(prefix) + "_combined_intervals.csv", index=False)
    combined_profiles.to_csv(str(prefix) + "_combined_profiles.csv", index=False)
    summary.to_csv(str(prefix) + "_summary.csv", index=False)
    dist.to_csv(str(prefix) + "_profile_distances.csv", index=False)
    boot.to_csv(str(prefix) + "_bootstrap_profile_distances.csv", index=False)
    Path(str(prefix) + "_report.md").write_text("\n".join(report_lines), encoding="utf-8")
    Path(str(prefix) + "_verdict.txt").write_text(verdict, encoding="utf-8")

    return {
        "summary": summary,
        "avg_profiles": avg,
        "profile_distances": dist,
        "external_profile_distances": external_dist,
        "bootstrap_profile_distances": boot,
        "control_intervals": control_intervals,
        "control_profiles": control_profiles,
        "combined_intervals": combined_intervals,
        "combined_profiles": combined_profiles,
        "sizes": pd.DataFrame({"matched_control_sizes": list(map(int, sizes))}),
        "verdict": verdict,
    }
