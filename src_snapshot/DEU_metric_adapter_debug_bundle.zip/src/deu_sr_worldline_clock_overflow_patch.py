"""
Overflow patch for deu_sr_worldline_clock_patch.py.

Run AFTER loading deu_sr_worldline_clock_patch.py:

    %run -i deu_sr_worldline_clock_patch.py
    %run -i deu_sr_worldline_clock_overflow_patch.py

or:

    exec(open('deu_sr_worldline_clock_overflow_patch.py').read(), globals())

Why this exists
---------------
The worldline control builder creates one-row diamond DataFrames containing
`interval_bits`, a Python integer bit-mask. For interval sizes of a few hundred
or larger, that integer can be thousands of bits wide. Pandas sometimes tries to
coerce it to int64/float64 during DataFrame construction and raises:

    OverflowError: int too large to convert to float

This patch replaces only `build_worldline_control_samples(...)` and constructs
those one-row frames with `interval_bits` explicitly stored as dtype=object.
No causet, radar, tube-clock, or geometry logic is changed.
"""

from __future__ import annotations

from typing import Sequence, Tuple
import pandas as pd


def _wl_safe_single_diamond_df(a, b, bits, V):
    """One-row diamond DataFrame with huge bit-mask stored as Python object."""
    df = pd.DataFrame({
        "a_index": pd.Series([int(a)], dtype="int64"),
        "b_index": pd.Series([int(b)], dtype="int64"),
        "V": pd.Series([int(V)], dtype="int64"),
    })
    # Add interval_bits after the numeric frame is constructed, forcing object.
    df["interval_bits"] = pd.Series([int(bits)], dtype=object)
    # Stable column order expected by downstream code.
    return df[["a_index", "b_index", "interval_bits", "V"]]


def _wl_process_control_interval(c, a, b, n, model, v_targets, v_band):
    """Build radar events/meta/tubes for one control interval."""
    bits = int(c.descendant_bits[int(a)] & c.ancestor_bits[int(b)])
    ddf = _wl_safe_single_diamond_df(a, b, bits, n)
    ev, meta = radar_events_for_diamond_rows(c, ddf, str(model))
    tubes = time_dilation_tube_rows_for_diamonds(
        c,
        ev,
        str(model),
        v_targets=v_targets,
        v_band=v_band,
    )
    return ev, meta, tubes


def build_worldline_control_samples(
    sizes: Sequence[int],
    reps_per_size: int = 4,
    seed: int = 12345,
    v_targets: Sequence[float] = (0.0, 0.2, 0.4, 0.6, 0.75),
    v_band: float = 0.075,
    max_models: Sequence[str] = ("minkowski_2p1D", "minkowski_3p1D", "random_DAG", "chain_1D"),
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    Overflow-safe replacement for the original control builder.

    Only change: one-row control diamond frames store interval_bits as object.
    """
    event_parts = []
    meta_parts = []
    tube_parts = []
    models = set(max_models)

    for n in sizes:
        n = int(max(12, n))

        if "chain_1D" in models:
            c, a, b = make_chain_interval_causet(n)
            ev, meta, tubes = _wl_process_control_interval(c, a, b, n, "chain_1D", v_targets, v_band)
            if len(ev):
                event_parts.append(ev)
            if len(meta):
                meta_parts.append(meta)
            if len(tubes):
                tube_parts.append(tubes)

        for rep in range(int(reps_per_size)):
            base = int(seed + 100000 * rep + 97 * n)

            if "minkowski_2p1D" in models:
                c, a, b = make_minkowski_interval_causet(n, d=3, seed=base + 3)
                ev, meta, tubes = _wl_process_control_interval(c, a, b, n, "minkowski_2p1D", v_targets, v_band)
                if len(ev):
                    event_parts.append(ev)
                if len(meta):
                    meta_parts.append(meta)
                if len(tubes):
                    tube_parts.append(tubes)

            if "minkowski_3p1D" in models:
                c, a, b = make_minkowski_interval_causet(n, d=4, seed=base + 4)
                ev, meta, tubes = _wl_process_control_interval(c, a, b, n, "minkowski_3p1D", v_targets, v_band)
                if len(ev):
                    event_parts.append(ev)
                if len(meta):
                    meta_parts.append(meta)
                if len(tubes):
                    tube_parts.append(tubes)

            if "random_DAG" in models:
                c, a, b = make_random_dag_interval_causet(n, p=0.025, seed=base + 999)
                ev, meta, tubes = _wl_process_control_interval(c, a, b, n, "random_DAG", v_targets, v_band)
                if len(ev):
                    event_parts.append(ev)
                if len(meta):
                    meta_parts.append(meta)
                if len(tubes):
                    tube_parts.append(tubes)

    events = pd.concat(event_parts, ignore_index=True) if event_parts else pd.DataFrame()
    meta = pd.concat(meta_parts, ignore_index=True) if meta_parts else pd.DataFrame()
    tubes = pd.concat(tube_parts, ignore_index=True) if tube_parts else pd.DataFrame()
    return events, meta, tubes


print("Loaded overflow-safe build_worldline_control_samples(...).")
