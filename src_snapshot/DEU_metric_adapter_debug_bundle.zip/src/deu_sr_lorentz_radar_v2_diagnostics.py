"""
Stricter diagnostics for the DEU graph-radar SR audit.

Run this AFTER running deu_sr_lorentz_radar_patch.py and producing a result like
    lorentz_512 = run_lorentz_radar_audit_from_foam_result(...)

Typical use:
    %run -i deu_sr_lorentz_radar_v2_diagnostics.py
    radar_v2_512 = strict_lorentz_radar_postprocess(
        lorentz_512,
        foam_label="foam_cap512_SR_window",
        run_label="cap512_v2",
        out_dir=OUT,
    )
    display(radar_v2_512["strict_summary"])
    display(radar_v2_512["gamma_bins"])
    print(radar_v2_512["strict_verdict"])

Purpose:
  The original radar audit used median gamma error as a pass condition. That can be
  too permissive when gamma_pred has a narrow range and gamma_measured is nearly
  constant. This patch adds binned gamma diagnostics and a stricter verdict.

Interpretation:
  - invariant and light-cone tests can pass while Lorentz-factor/time-dilation fails.
  - a true graph-SR radar pass should show a monotone, binned relation between
    measured gamma=t/tau and predicted gamma=1/sqrt(1-v^2), not merely small median
    absolute error.
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, Optional, Sequence

import numpy as np
import pandas as pd


def _fit_line(x, y, min_points: int = 4) -> Dict[str, float]:
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    m = np.isfinite(x) & np.isfinite(y)
    x = x[m]; y = y[m]
    if len(x) < min_points:
        return {"slope": np.nan, "intercept": np.nan, "r2": np.nan, "corr": np.nan, "n_fit": int(len(x))}
    slope, intercept = np.polyfit(x, y, 1)
    pred = intercept + slope * x
    ss_res = float(np.sum((y - pred) ** 2))
    ss_tot = float(np.sum((y - y.mean()) ** 2))
    r2 = np.nan if ss_tot <= 0 else 1.0 - ss_res / ss_tot
    corr = float(np.corrcoef(x, y)[0, 1]) if len(x) >= 3 and np.std(x) > 0 and np.std(y) > 0 else np.nan
    return {"slope": float(slope), "intercept": float(intercept), "r2": float(r2), "corr": corr, "n_fit": int(len(x))}


def _radar_fit_filter(events: pd.DataFrame) -> pd.DataFrame:
    df = events.copy()
    need = ["is_top", "on_observer", "v_radar", "t_radar", "tau_chain", "minkowski_inv", "gamma_pred", "gamma_measured"]
    for c in need:
        if c not in df.columns:
            raise ValueError(f"events is missing required column: {c}")
    out = df[
        (~df["is_top"].astype(bool))
        & (~df["on_observer"].astype(bool))
        & np.isfinite(df["v_radar"])
        & (df["v_radar"] > 0.05)
        & (df["v_radar"] < 0.97)
        & (df["t_radar"] >= 2.0)
        & (df["tau_chain"] >= 1.0)
        & (df["minkowski_inv"] > 0)
        & np.isfinite(df["gamma_pred"])
        & np.isfinite(df["gamma_measured"])
    ].copy()
    return out


def binned_gamma_diagnostics(
    events: pd.DataFrame,
    v_bins: Sequence[float] = (0.05, 0.15, 0.25, 0.35, 0.45, 0.55, 0.65, 0.75, 0.85, 0.95),
    min_events_per_model_bin: int = 100,
    min_interval_bins: int = 3,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Compute per-model binned gamma relation.

    To reduce domination by a few large diamonds, first aggregate to one median row
    per (model, interval_id, v_bin), then aggregate those interval-bin medians to
    model-level v bins.
    """
    fit = _radar_fit_filter(events)
    if len(fit) == 0:
        return pd.DataFrame(), pd.DataFrame()
    fit["v_bin"] = pd.cut(fit["v_radar"], bins=list(v_bins), include_lowest=True, right=False)
    fit = fit.dropna(subset=["v_bin"]).copy()
    if len(fit) == 0:
        return pd.DataFrame(), pd.DataFrame()

    interval_bin = (
        fit.groupby(["model", "interval_id", "v_bin"], observed=True)
        .agg(
            n_events=("v_radar", "size"),
            v_med=("v_radar", "median"),
            gamma_pred_med=("gamma_pred", "median"),
            gamma_measured_med=("gamma_measured", "median"),
            gamma_rel_err_med=("gamma_pred", lambda s: np.nan),
        )
        .reset_index()
    )
    # Recompute relative error from medians.
    interval_bin["gamma_rel_err_med"] = (
        np.abs(interval_bin["gamma_measured_med"] - interval_bin["gamma_pred_med"])
        / np.maximum(1e-12, interval_bin["gamma_pred_med"])
    )

    bin_summary = (
        interval_bin.groupby(["model", "v_bin"], observed=True)
        .agg(
            n_interval_bins=("interval_id", "nunique"),
            n_events=("n_events", "sum"),
            v_med=("v_med", "median"),
            gamma_pred_med=("gamma_pred_med", "median"),
            gamma_measured_med=("gamma_measured_med", "median"),
            gamma_rel_err_med=("gamma_rel_err_med", "median"),
        )
        .reset_index()
    )
    bin_summary = bin_summary[
        (bin_summary["n_events"] >= int(min_events_per_model_bin))
        & (bin_summary["n_interval_bins"] >= int(min_interval_bins))
    ].copy()

    rows = []
    for model, sub in bin_summary.groupby("model", observed=True):
        sub = sub.sort_values("v_med")
        fitres = _fit_line(sub["gamma_pred_med"], sub["gamma_measured_med"], min_points=4)
        # Monotonicity of measured gamma with v/gamma_pred.
        if len(sub) >= 3:
            diffs = np.diff(sub["gamma_measured_med"].to_numpy(dtype=float))
            monotone_fraction = float(np.mean(diffs >= -1e-9)) if len(diffs) else np.nan
            dynamic_range = float(sub["gamma_measured_med"].max() - sub["gamma_measured_med"].min())
        else:
            monotone_fraction = np.nan
            dynamic_range = np.nan
        rows.append({
            "model": model,
            "n_gamma_bins": int(len(sub)),
            "gamma_pred_min": float(sub["gamma_pred_med"].min()) if len(sub) else np.nan,
            "gamma_pred_max": float(sub["gamma_pred_med"].max()) if len(sub) else np.nan,
            "gamma_measured_min": float(sub["gamma_measured_med"].min()) if len(sub) else np.nan,
            "gamma_measured_max": float(sub["gamma_measured_med"].max()) if len(sub) else np.nan,
            "gamma_measured_dynamic_range": dynamic_range,
            "binned_gamma_slope": fitres["slope"],
            "binned_gamma_intercept": fitres["intercept"],
            "binned_gamma_r2": fitres["r2"],
            "binned_gamma_corr": fitres["corr"],
            "binned_gamma_n_fit": fitres["n_fit"],
            "binned_gamma_monotone_fraction": monotone_fraction,
            "binned_gamma_rel_err_median": float(sub["gamma_rel_err_med"].median()) if len(sub) else np.nan,
        })
    diag = pd.DataFrame(rows)
    return bin_summary, diag


def strict_lorentz_radar_verdict(summary: pd.DataFrame, gamma_diag: pd.DataFrame, foam_label: str) -> str:
    if summary is None or len(summary) == 0 or foam_label not in set(summary["model"]):
        return "UNDETERMINED: no foam summary found."
    row = summary[summary["model"] == foam_label].iloc[0]
    grow = gamma_diag[gamma_diag["model"] == foam_label].iloc[0] if gamma_diag is not None and len(gamma_diag) and foam_label in set(gamma_diag["model"]) else None

    inv_ok = (
        float(row.get("invariant_r2", np.nan)) >= 0.75
        and 0.45 <= float(row.get("invariant_slope_tau2_vs_t2minusr2", np.nan)) <= 1.55
    )
    lc_ok = float(row.get("lightcone_margin_near_minus_bulk", -np.inf)) >= 0.10
    n_ok = float(row.get("n_events_fit", 0)) >= 1000

    raw_gamma_ok = (
        float(row.get("gamma_corr", np.nan)) >= 0.30
        and float(row.get("gamma_r2", np.nan)) >= 0.10
        and 0.35 <= float(row.get("gamma_slope_measured_vs_pred", np.nan)) <= 1.65
    )
    binned_gamma_ok = False
    if grow is not None:
        binned_gamma_ok = (
            float(grow.get("binned_gamma_n_fit", 0)) >= 4
            and float(grow.get("binned_gamma_corr", np.nan)) >= 0.50
            and float(grow.get("binned_gamma_r2", np.nan)) >= 0.25
            and 0.35 <= float(grow.get("binned_gamma_slope", np.nan)) <= 1.65
            and float(grow.get("binned_gamma_monotone_fraction", np.nan)) >= 0.60
        )
    gamma_ok = raw_gamma_ok or binned_gamma_ok

    notes = []
    if inv_ok:
        notes.append("radar invariant is coherent")
    else:
        notes.append("radar invariant is weak or mis-scaled")
    if gamma_ok:
        notes.append("Lorentz-factor/time-dilation relation has a monotone fitted signal")
    else:
        notes.append("Lorentz-factor/time-dilation relation is not yet recovered")
    if lc_ok:
        notes.append("near-null events sit closer to v=1 than bulk events")
    else:
        notes.append("light-cone boundary proxy is weak")

    prefix = "PASS / PROMISING" if (inv_ok and gamma_ok and lc_ok and n_ok) else ("PARTIAL PASS" if (inv_ok and lc_ok and n_ok) else "NOT YET PASSING")
    if prefix == "PASS / PROMISING":
        body = "graph radar coordinates pass invariant, Lorentz-factor, and light-cone tests."
    elif prefix == "PARTIAL PASS":
        body = "graph radar coordinates support invariant/light-cone structure, but do not yet derive the Lorentz factor/time dilation."
    else:
        body = "graph radar coordinates are not yet a reliable SR-kinematics derivation."
    return prefix + ": " + body + " Details: " + "; ".join(notes) + "."


def strict_lorentz_radar_postprocess(
    lorentz_result: Dict[str, object],
    foam_label: str,
    run_label: str = "lorentz_v2",
    out_dir: Optional[str | Path] = None,
) -> Dict[str, object]:
    events = lorentz_result["events"]
    summary = lorentz_result["summary"].copy()
    gamma_bins, gamma_diag = binned_gamma_diagnostics(events)
    verdict = strict_lorentz_radar_verdict(summary, gamma_diag, foam_label=foam_label)

    strict_summary = summary.merge(gamma_diag, on="model", how="left") if len(gamma_diag) else summary.copy()
    result = {
        "strict_summary": strict_summary,
        "gamma_bins": gamma_bins,
        "gamma_diagnostics": gamma_diag,
        "strict_verdict": verdict,
    }
    if out_dir is not None:
        out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
        strict_summary.to_csv(out / f"lorentz_radar_strict_summary_{run_label}.csv", index=False)
        gamma_bins.to_csv(out / f"lorentz_radar_gamma_bins_{run_label}.csv", index=False)
        gamma_diag.to_csv(out / f"lorentz_radar_gamma_diagnostics_{run_label}.csv", index=False)
        (out / f"lorentz_radar_strict_verdict_{run_label}.txt").write_text(verdict, encoding="utf-8")
    return result
